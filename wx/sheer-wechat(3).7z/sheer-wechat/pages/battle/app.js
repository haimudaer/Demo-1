const app = getApp()
let timeout1 = null, timeout2 = null, timeout3 = null, timeout4 = null, timeout5 = null, timeout6 = null, timeout7 = null, timeout8 = null, timeout9 = null, timeout10 = null, timeout11 = null, timeout12 = null, timeout13 = null, timeout14 = null, timeout15 = null;
let heartbeatSetinter=null,heartbeatTime=4000;//定时向socket  发送心跳  5s
var socketOpen = false; //判断socket处于打开状态才发送消息
var responseTimeout=null,responseTime=3000,contraryIsSubmitTimeout=null;//socket无响应  12s 后返回上一页  网络异常
//媒体播放
const innerAudioContext = wx.createInnerAudioContext();
const innerAudioContextTime = wx.createInnerAudioContext(); //倒计时

Page({
  data: {
    ipImg: app.ipImg,
    serverUser: {},

    matchClassName: "bounceInUp",
    matchIsShow: true,
    robotRandom: 3, //机器人答题时间
    interval: null,
    matchInterval: null,
    canvasInterval: null,
    canvasCount: 0, //canvas倒计时

    /**星级 */
    starLevel: 0,

    /**匹配页面逻辑 */
    matchInLeftClassName: "bounceInLeft",
    matchInRightClassName: "bounceInRight",
    matchInIsShow: false,
    vsClassName: "jello",
    matchCountNumber: 5, //匹配时间  10s 

    /**匹配到的两个用户开始答题 */
    guestUser: null, //敌人
    houseOwnerUser: null, //房主
    startAnswerIsShow: false, //是否显示开始答题
    subjects: [], //题库
    countNumber: 10, //答题时间 倒计时 （10 - countNumber） 也就是答题时间
    subjectItem: [], //当前答题对象
    subjectNumber: 1, //当前第几题
    houseId: null, //存放房间ID
    answerClassName: "", //动画样式
    isAnswerClassName: false,
    firstAnswer: "",
    isFirstAnswer: false,
    isShowAnswer: false,
    isEnd: false, //显示最后一道题得分提示
    isEndclassName: "zoomIn",
    houseOwnerAnswerItem: null, //我选的答案
    guestAnswerItem: null, //敌人的答案
    houseScore: 0, //我方分数
    guestScore: 0, //地方分数
    houseHeight: 0, //我方百分比
    guestHeight: 0, //敌方百分比
    totalScore: 0, //总分

    /**对战结果 */
    isResultShow: false, // 是否显示结果页面
    houseResult: null, //我方的答题结果 
    guestResult: null, //敌方的答题结果
    houseResultWidth: 0, //我方百分比宽度
    guestResultWidth: 0, //敌方百分比宽度

    /**好友对战 */
    friendsPK: false, //是否好友对战
    isShowFriendsPK: false, // 是否显示好友对战
    isHouse: false, //确定是否是房主
    houseUserId: null, //房主的userID
    isFriendsStart: false, //是否已经点击开始了

    /**机器人对战 */
    robotPK: false, //是否机器人对战

    isShareResult: null, //是否分享结果

    isSelect: true, //设置是否可选择答案
    isProp: false, //设置是否可使用道具

    prop: null, //存放道具
    isProp1: false,   //当前答题是否使用过排除卡
    isProp2: false,   //当前答题是否使用过创口贴
    isProp3: false,   //当前答题是否使用过秒选卡
    cutAnswerId: null, //存放创口贴服务端返回的答案ID
    shareOnceStatus:true,//新增当前页面只能分享一次获得20经验

    submited:false,//false 才能提交  避免defaultSubmit 重复提交

    //音效路径
    MP3: {
      match: app.ipImg + "match.mp3",
      success: app.ipImg + "success.wav",
      correct: app.ipImg + "correct.mp3",
      error: app.ipImg + "error_.mp3",
      time: app.ipImg + "time.mp3",
    },

  },
  onReady: function () {
    let thas = this;
    this.canvasProgressborder();
    innerAudioContext.src = thas.data.MP3.match;
    innerAudioContextTime.src = thas.data.MP3.time;
    innerAudioContextTime.loop = true;
    innerAudioContext.onPlay(() => {
      console.log('开始播放')
    })

    innerAudioContext.onPause(() => {
      console.log('暂停播放')
    })

  },
  onLoad: function (e) {
    console.log(e)
    const thas = this;
    console.log(e);
    /**测试好友 */
    clearTimeout(responseTimeout);
    clearTimeout(contraryIsSubmitTimeout);
    clearInterval(this.data.matchInterval); //清空定时器
    clearInterval(this.data.interval);
    clearInterval(this.data.canvasInterval);
    clearTimeout(timeout1);
    clearTimeout(timeout2);
    clearTimeout(timeout3);
    clearTimeout(timeout4);
    clearTimeout(timeout5);
    clearTimeout(timeout6);
    clearTimeout(timeout7);
    clearTimeout(timeout8);
    clearTimeout(timeout9);
    clearTimeout(timeout10);
    clearTimeout(timeout11);
    clearTimeout(timeout12);
    clearTimeout(timeout13);
    clearTimeout(timeout14);
    clearTimeout(timeout15);
    socketOpen = false;
    //好友对战
    if (e.type == 100) {
      thas.setData({
        friendsPK: true,
        isShowFriendsPK: true,
      });
      wx.setNavigationBarTitle({
        title: '好友对战' 
      })
    }
    /**机器人对战 */
    else if (e.type == 200) {
      thas.setData({
        robotPK: true
      });
      wx.setNavigationBarTitle({
        title: 'PK机器人' 
      })
    }
    /**排位赛 关卡 */
    else {
      thas.setData({
        starLevel: e.type
      });
    }

    /**假如 houseId不为空 证明是好友进来*/
    if (e.houseId != undefined) {
      thas.setData({
        houseId: e.houseId
      });
    }

    //获取登录serverUser
    thas.setData({
      serverUser: wx.getStorageSync('serverUser')
    });
    /**获取道具 */
    app.http(app.api.getSelfProp, {}, function (res) {
      thas.setData({
        prop: res.data.body
      });
    }, function () { }, true);
    
    //如果是机器人对战
    if (thas.data.robotPK) {
      thas.sendWebSocket();//发起websocket连接
    }else{
      // 检测场次是否已经答完
      app.http(app.api.isPlay, {}, function (res) {
        if (res.data.body) {
          thas.sendWebSocket();//发起websocket连接
        }else {
          wx.showToast({
            title: '今日场次已满，请明日继续',
            icon: "none",
            duration: 2000
          })
        }
      }, function () { }, true);
    }



    
  },
  /**监听页面显示 */
  onShow: function () {
    let thas = this;
    wx.hideShareMenu(); // 先关闭按钮的显示
  },
  /**监听页面隐藏 */
  onHide: function () {
    innerAudioContextTime.pause(); //暂停倒计时
    if (!this.data.friendsPK) {
      this.close();
      if (!this.data.startAnswerIsShow && !this.data.isResultShow) {
        wx.showModal({
          title: '取消匹配',
          showCancel: false,
          success: function (res) {
            wx.navigateBack({ changed: true });//返回上一页
          }
        })
      }
      else if (this.data.startAnswerIsShow) {
        wx.showModal({
          title: '中途退出',
          showCancel: false,
          success: function (res) {
            wx.navigateBack({ changed: true });//返回上一页
          }
        })
      }
    }
  },
  /**监听页面卸载 */
  onUnload: function () {
    let thas=this;
    console.log("页面卸载了");
    // clearInterval(heartbeatSetinter); //清空定时器发送心跳
    clearInterval(this.data.matchInterval); //清空定时器
    clearInterval(this.data.interval);
    clearInterval(this.data.canvasInterval);
    clearTimeout(responseTimeout);
    clearTimeout(contraryIsSubmitTimeout);
    clearTimeout(timeout1);
    clearTimeout(timeout2);
    clearTimeout(timeout3);
    clearTimeout(timeout4);
    clearTimeout(timeout5);
    clearTimeout(timeout6);
    clearTimeout(timeout7);
    clearTimeout(timeout8);
    clearTimeout(timeout9);
    clearTimeout(timeout10);
    clearTimeout(timeout11);
    clearTimeout(timeout12);
    clearTimeout(timeout13);
    clearTimeout(timeout14);
    clearTimeout(timeout15);
    socketOpen = false;
    innerAudioContextTime.pause(); //暂停倒计时

    wx.closeSocket();
    //监听关闭
    wx.onSocketClose(function (res) {
      socketOpen = false;
      // clearInterval(heartbeatSetinter); //清空定时器发送心跳
      console.log('WebSocket 已关闭！',res);
      if(thas.data.friendsPK){
            wx.navigateBack({ changed: true });//返回上一页
      }
    })

  },
  /**分享--挑战 */
  onShareAppMessage: function (e) {
    console.log(e);
    let thas = this;
    let path = "", title = "";
    if (e.target.dataset.type == 1) {
      title = "快来看看我，惊不惊喜！意不意外！";
      path = "/pages/index/app";
    }
    else {
      title = "来来来，快来挑战我";
      path = '/pages/index/app?houseId=' + thas.data.houseId + '&type=100';
    };
    //只能第一次分享获取经验
    if(thas.data.shareOnceStatus&&e.target.dataset.type == 1){
       app.http(app.api.addScore, { flag: 0 }, function (res) {
            thas.setData({
              isShareResult: 1,
              shareOnceStatus:false
            });
          }, function () { }, true);
    };
    return {
      title: title,
      path: path,
      //imageUrl: this.data.ipImg + "meun-3.png",
      success: function () {
        if (e.target.dataset.type == 1 && thas.data.isShareResult == null) {
          app.http(app.api.addScore, { flag: 0 }, function (res) {
            thas.setData({
              isShareResult: 1
            });
          }, function () { }, true);
        }
      },
      fail: function () {
        console.log("失败回调..");
      }
    }
  },
  /** 发起连接 */
  sendWebSocket: function () {
    let thas = this;
    //打开链接
    wx.connectSocket({
      url: app.websocketIp,
      header: {
        'content-type': 'application/json',
        'Cookie': 'JSESSIONID=' + app.generatePbcId('reopen'),
        'testString': 'PBC_TEST',
      },
      // success:function(response){
      //   heartbeatSetinter=setInterval(() => {
      //      thas.send({ event: "heartbeat", body: '' });
      //   }, heartbeatTime);
      // },
    })

    //监听链接是否打开
    wx.onSocketOpen(function (res) {
      socketOpen = true;
      console.log("链接已打开");
      // heartbeatSetinter=setInterval(() => {
      //        thas.send({ event: "heartbeat", body: '' });
      // }, heartbeatTime);
      thas.send({ event: "auth", body: thas.data.serverUser.id, userId: thas.data.serverUser.id });
    })

    //链接失败
    wx.onSocketError(function (res) {
      socketOpen = false;
      console.log('WebSocket连接打开失败，请检查！');
      // clearInterval(heartbeatSetinter); //清空定时器发送心跳
      wx.showModal({
        title: '连接失败',
        content: '',
        showCancel: false,
        confirmText: '返回',
        confirmColor: '#CB2E2D',
        success: function (res) {
          thas.out();
        }
      });
    })

    //接收服务器返回的内容
    wx.onSocketMessage(function (res) {
      thas.responseFun('end');
      try {
        if (res && res.data && JSON.parse(res.data).event == 'heartbeat') {//心跳
          console.log(res.data, '心跳包响应');
          return false;
        } else {
          thas.result(res.data);
        }
      } catch (e) {
        thas.result(res.data);
        console.error(e);
      }
    })
  },
  /**打开链接 */
  open: function () {
    let thas = this;
    wx.connectSocket({
      url: app.websocketIp,
      header:{
          'content-type':'application/json',
          'Cookie':'JSESSIONID='+app.generatePbcId('reopen'),
          'testString':'PBC_TEST',
        },
      success: function () {
        socketOpen = true;
        thas.send({ event: "auth", body: thas.data.serverUser.id,userId:thas.data.serverUser.id });
        // heartbeatSetinter=setInterval(() => {
        //      thas.send({ event: "heartbeat", body: '' });
        //   }, heartbeatTime);
      }
    })
  },
  /**向服务端发送消息 */
  send: function (message) {
    let thas = this;
    console.log(message);
    if (socketOpen) {
      wx.sendSocketMessage({
        data: JSON.stringify(message),
        header:{
          'content-type':'application/json',
           'Cookie':'JSESSIONID='+app.generatePbcId(),
          'testString':'PBC_TEST'
        },
        complete: function() {//发送消息开始异常监听
            if(message.event==='defaultSubmit'||message.event==='submitTimeOut'){
                thas.responseFun('start');
            }
        }
      })
    }
  },
  /**接收服务器返回的内容 */
  result: function (message) {
    let thas = this, data = null;
    message = JSON.parse(message);
    message.body = JSON.parse(message.body);
    if (typeof (message.body.data) != "undefined") {
      data = JSON.parse(message.body.data);
    }
    console.log(message);
    console.log(data);
    switch (message.body.code) {
      //匹配指令
      case 200:
        if (thas.data.friendsPK) {
          if (thas.data.houseId == null) {
            thas.send({ event: "inviteFriend", body: "",userId:thas.data.serverUser.id });
          }
          else {
            thas.send({ event: "friendEnterHouse", body: thas.data.houseId ,userId:thas.data.serverUser.id});
          }
        }
        //PK机器人
        else if (thas.data.robotPK) {
          timeout2 = setTimeout(() => {
            thas.send({ event: "robot", body: JSON.stringify({ level: 1, ipImg: thas.data.ipImg, isRobot: 1 }),userId:thas.data.serverUser.id });
          }, 500);
        }
        else {
          //修改websocket  参数  level：1-20  巅峰对决传过来为21  修改为20     等级     finalGame：Boolean  是否是巅峰对决
          // thas.send({ event: "match", body: thas.data.starLevel });
          let {starLevel}=(thas.data);
          thas.send({ event: "match", body: {level:(starLevel==21)?20:starLevel,finalGame:(starLevel==21?true:false)},userId:thas.data.serverUser.id });

        }
        break;
      //正在匹配
      case 2002:
        thas.setData({
          matchIsShow: true,
          matchInterval: setInterval(() => {
            if (thas.data.matchCountNumber == 0) {
              clearInterval(thas.data.matchInterval);
              console.log("通知服务器该匹配机器人了");
              //告诉服务器该匹配机器人
              let {starLevel}=(thas.data);
              thas.send({ event: "robot",
                            body: JSON.stringify({ 
                                level: (thas.data.starLevel==21)?20:thas.data.starLevel,
                                finalGame:(starLevel==21?true:false), 
                                ipImg: thas.data.ipImg, isRobot: 0 }),userId:thas.data.serverUser.id });
            }
            else if (thas.data.matchCountNumber < 0) {
              clearInterval(thas.data.matchInterval);
            }
            else {
              thas.setData({
                matchCountNumber: thas.data.matchCountNumber - 1,
              });
            }
          }, 1000)
        });
        break;
      //匹配成功
      case 2004:
        clearInterval(thas.data.matchInterval);
        thas.drawCircle(2);
        //存放user
        if (data.houseOwner.id == thas.data.serverUser.id) {
          thas.setData({
            houseOwnerUser: data.houseOwner, //房主
            guestUser: data.guest, //敌人
          });
        }
        else {
          thas.setData({
            houseOwnerUser: data.guest, //房主
            guestUser: data.houseOwner, //敌人
          });
        }

        //存放题库
        thas.setData({
          subjects: data.subjects,
          houseId: data.houseId,
          totalScore: data.score,
        });

        //调用筛选题目
        thas.screenAnswer();

        if (thas.data.friendsPK) {
          thas.setData({
            isShowFriendsPK: false,
            matchInIsShow: true, //显示匹配到的页面
          });
          //播放匹配音效
          if (wx.getStorageSync('isSound') == 1) {
            innerAudioContext.play();
          }

          timeout5 = setTimeout(() => {
            thas.setData({
              matchInLeftClassName: "bounceOutLeft",
              matchInRightClassName: "bounceOutRight",
              vsClassName: "bounceOut",
            });
          }, 3000);
          timeout6 = setTimeout(() => {
            thas.setData({
              matchInIsShow: false, //隐藏匹配到的页面
              startAnswerIsShow: true, //显示开始答题页面
            });
            timeout13 = setTimeout(() => {
              thas.setData({
                firstAnswer: "zoomIn",
                isFirstAnswer: true,
              });
              timeout14 = setTimeout(() => {
                thas.setData({
                  answerClassName: "zoomIn",
                  isAnswerClassName: true,
                });
                timeout15 = setTimeout(() => {
                  if (!thas.data.isResultShow) {
                    //开启计时器
                    thas.setData({
                      isShowAnswer: true
                    });
                    thas.startInterval();
                  }
                }, 1000);
              }, 1000);
            }, 1000);
          }, 4000);
        }
        else {
          timeout3 = setTimeout(() => {
            thas.setData({
              matchClassName: "bounceOutUp",
            });
            timeout4 = setTimeout(() => {
              //隐藏好友房间
              if (thas.data.friendsPK) {
                thas.setData({
                  isShowFriendsPK: false
                });
              }

              thas.setData({
                matchIsShow: false, //隐藏匹配页面
                matchInIsShow: true, //显示匹配到的页面
              });
              //播放匹配音效
              if (wx.getStorageSync('isSound') == 1) {
                innerAudioContext.play();
              }
            }, 1000);
            timeout5 = setTimeout(() => {
              thas.setData({
                matchInLeftClassName: "bounceOutLeft",
                matchInRightClassName: "bounceOutRight",
                vsClassName: "bounceOut",
              });
            }, 3000);
            timeout6 = setTimeout(() => {
              thas.setData({
                matchInIsShow: false, //隐藏匹配到的页面
                startAnswerIsShow: true, //显示开始答题页面
                firstAnswer: "zoomIn",
                isFirstAnswer: true
              });
              timeout12 = setTimeout(() => {
                thas.setData({
                  answerClassName: "zoomIn",
                  isAnswerClassName: true
                });
                timeout13 = setTimeout(() => {
                  if (!thas.data.isResultShow) {
                    //开启计时器
                    thas.setData({
                      isShowAnswer: true
                    });
                    thas.startInterval();
                  }
                }, 1000);
              }, 1000);
            }, 4000);
          }, 1000);
        }

        break;
      //返回答案
      case 2008:
        //添加已选答案
        if (thas.data.serverUser.id == data.userId && thas.data.houseOwnerUser.id == data.userId) {
          thas.setData({
            houseOwnerAnswerItem: data,
            houseScore: thas.data.houseScore + data.score,
          });
          thas.setData({
            houseHeight: Math.floor(thas.data.houseScore / thas.data.totalScore * 100),
          });
        }
        else {
          thas.setData({
            guestAnswerItem: data
          });
        }

        //往集合里面添加状态--设置单边选择
        for (let i = 0; i < thas.data.subjectItem.itemList.length; i++) {
          let item = thas.data.subjectItem.itemList[i];
          if (data.userId == thas.data.houseOwnerUser.id && item.id == data.answer) {
            item.isAnswerMy = data.isCorrect;
            item.className = data.isCorrect ? "pulse correct-bg" : "shake error-bg";
            //播放匹配音效
            // if (wx.getStorageSync('isSound') == 1) {
            //   if (data.isCorrect) {
            //     innerAudioContext.src = thas.data.MP3.correct;
            //     innerAudioContext.play();
            //   }
            //   else {
            //     innerAudioContext.src = thas.data.MP3.error;
            //     innerAudioContext.play();
            //   }
            // }
          }
        }
        //添加  contraryIsSubmit  false  开启倒计时  如若不能进入下一题   则终止游戏
        if(thas.data.countNumber==0&&!thas.data.isEnd){
          if(!data.contraryIsSubmit){

             contraryIsSubmitTimeout=setTimeout(() => {
               console.log('contraryIsSubmit',false,'````````````')
                  thas.clearAll();
                  socketOpen = false;
                  wx.closeSocket();
                  wx.showModal({
                      title: '网络异常',
                      showCancel: false,
                      confirmText:'确认',
                      confirmColor:'#42C18A',
                      success: function (res) {
                          thas.out();
                      }
                  });
            }, responseTime);
          }
        }
        //判断敌方是否选答案了 -- 等待敌方答题结束之后再赋值
        if (data.contraryIsSubmit) {
          thas.setData({
            guestScore: thas.data.guestScore + thas.data.guestAnswerItem.score,
          });
          thas.setData({
            guestHeight: Math.floor(thas.data.guestScore / thas.data.totalScore * 100),
          });

          //显示答案
          for (let i = 0; i < thas.data.subjectItem.itemList.length; i++) {
            let item = thas.data.subjectItem.itemList[i];
            //正确答案
            try {
              if (!thas.data.houseOwnerAnswerItem.isCorrect && !thas.data.guestAnswerItem.isCorrect && data.correctAnswer == item.id) {
                item.className = "";
                item.correctClassName = "pulse correct-bg";
              }
            }
            catch (e) { }

            //敌方答案
            if (item.id == thas.data.guestAnswerItem.answer) {
              item.isAnswerTo = thas.data.guestAnswerItem.isCorrect;
              item.className = "";
              item.guestclassName = thas.data.guestAnswerItem.isCorrect ? "pulse correct-bg" : "shake error-bg";
            }
          }

          //切换下一题
          thas.closeInterval();

        }


        //重新赋值
        thas.setData({
          subjectItem: thas.data.subjectItem
        });

        break;

      //答题结果
      case 2006:
        if (thas.data.subjectNumber <= thas.data.subjects.length) {
          this.clearAll(); //清空定时器
          wx.showModal({
            title: '游戏中止',
            showCancel: false,
            success: function (res) {
              thas.setData({
                isResultShow: true,
                startAnswerIsShow: false,
                matchIsShow: false,
                matchInIsShow: false,
              });
            }
          })
        }

        if (data[0].id == thas.data.houseOwnerUser.id) {
          thas.setData({
            houseResult: data[0], //我方的答题结果 
            guestResult: data[1], //敌方的答题结果
          });
        }
        else {
          thas.setData({
            houseResult: data[1], //我方的答题结果 
            guestResult: data[0], //敌方的答题结果
          });
        }

        //计算双方得分比例
        let leftProportion = Math.floor(thas.data.houseResult.score / (thas.data.guestResult.score + thas.data.houseResult.score) * 100);
        let rightProportion = Math.floor(thas.data.guestResult.score / (thas.data.guestResult.score + thas.data.houseResult.score) * 100);

        //双方得0分
        if ((thas.data.houseResult.score == 0 && thas.data.guestResult.score == 0) || thas.data.houseResult.score == thas.data.guestResult.score) {
          thas.setData({
            houseResultWidth: 50,
            guestResultWidth: 50,
          });
        }
        else {

          if (thas.data.houseResult.id == thas.data.houseOwnerUser.id) {
            thas.setData({
              houseResultWidth: leftProportion,
              guestResultWidth: 100 - leftProportion,
            });
          }
          else {
            thas.setData({
              houseResultWidth: 100 - leftProportion,
              guestResultWidth: leftProportion,
            });
          }

        }

        //播放匹配音效
        if (wx.getStorageSync('isSound') == 1 && thas.data.houseResult.score > thas.data.guestResult.score) {
          innerAudioContext.src = thas.data.MP3.success;
          innerAudioContext.play();
        }

        break;
      //开房间--返回房间号
      case 2014:
        thas.setData({
          houseId: data
        });
        break;
      //好友加入房间成功
      case 2016:
        //存放user
        thas.setData({
          houseUserId: data.houseOwner.id,
        });
        if (data.houseOwner.id == thas.data.serverUser.id) {
          thas.setData({
            isHouse: true,
            houseOwnerUser: data.houseOwner, //房主
            guestUser: data.guest, //敌人
          });
        }
        else {
          thas.setData({
            houseOwnerUser: data.guest, //房主
            guestUser: data.houseOwner, //敌人
          });
        }
        break;
      case 2018:

        break;
      //房主放弃对战
      case 2022:
        thas.out();
        break;
      //非房主放弃对战
      case 2020:
        wx.showModal({
          title: '您的好友退出了房间',
          content: '请重新邀请您的好友',
          showCancel: false,
          confirmText:'知道了',
          confirmColor:'#CB2E2D',
          success: function (res) {
               thas.out();
          }
        });
        thas.setData({
          guestUser: null
        });
        break;
      //对方退出房间返回上一页
      case 2024:
        thas.out();
        break;
      //掉线
      case 2001:
        wx.showModal({
          title: '您的对手退出了房间',
          content: '',
          showCancel: false,
          success: function (res) {

          }
        })
        break;
        
      //创口贴
      case 2026:
        //往集合里面添加排除样式
        thas.setData({
          cutAnswerId: data.answerId,
        });
        for (let i = 0; i < thas.data.subjectItem.itemList.length; i++) {
          let item = thas.data.subjectItem.itemList[i];
          if (data.userId == thas.data.houseOwnerUser.id && item.id == data.answerId) {
            item.disabledClassName = "disabled-bg";
            item.isDisabled = true;
            wx.showToast({ title: '对方对你使用了创口贴', icon: "none", duration: 1000 });
            break;
          }
        }

        //重新赋值
        thas.setData({
          subjectItem: thas.data.subjectItem
        });
        break;
      //创口贴--我方看到
      case 2038:
        for (let i = 0; i < thas.data.subjectItem.itemList.length; i++) {
          let item = thas.data.subjectItem.itemList[i];
          if (item.id == data.answerId) {
            item.disabledClassName = "ckt-bg";
            break;
          }
        }
        //重新赋值
        thas.setData({
          subjectItem: thas.data.subjectItem
        });
        break;
      //排除卡
      case 2028:
        //往集合里面添加排除样式
        for (let i = 0; i < thas.data.subjectItem.itemList.length; i++) {
          let item = thas.data.subjectItem.itemList[i];
          if (data.userId == thas.data.houseOwnerUser.id && item.id == data.answerId) {
            item.disabledClassName = "disabled-bg";
            item.isDisabled = true;
            break;
          }
        }

        if (data.userId == thas.data.houseOwnerUser.id) {
          for (let j = 0; j < thas.data.prop.length; j++) {
            if (thas.data.prop[j].propId == 2) {
              thas.data.prop[j].num = thas.data.prop[j].num - 1;
              break;
            }
          }
          thas.setData({
            prop: thas.data.prop
          });
        }

        //重新赋值
        thas.setData({
          subjectItem: thas.data.subjectItem
        });
        break;
      //秒选卡
      case 2030:
        //减数量
        if (data.userId == thas.data.houseOwnerUser.id) {
          for (let j = 0; j < thas.data.prop.length; j++) {
            if (thas.data.prop[j].propId == 4) {
              thas.data.prop[j].num = thas.data.prop[j].num - 1;
              break;
            }
          }
          thas.setData({
            prop: thas.data.prop
          });
        }

        //发送答案
        let msg = {
          userTime: thas.data.countNumber,
          answer: data.answerId,
          subject: thas.data.subjectItem.id,
          houseId: thas.data.houseId
        }
        // submited  false  才可以提交答案
        if(!thas.data.submited){
           thas.send({ event: "submitAnswer", body: JSON.stringify(msg) ,userId:thas.data.serverUser.id});
        }
        break;
      //创口贴减数量
      case 2032:
        if (data == thas.data.houseOwnerUser.id) {
          for (let j = 0; j < thas.data.prop.length; j++) {
            if (thas.data.prop[j].propId == 3) {
              thas.data.prop[j].num = thas.data.prop[j].num - 1;
              break;
            }
          }
          thas.setData({
            prop: thas.data.prop
          });
        }
        break;
      //不做处理
      case 2012:  
        break;
      //没有题--关闭
      case 202:
              thas.out();
        break;
      default:
          thas.tipsMessage(message.body.code, message.body.message);
        break;
    }
  },
  /**筛选题目 */
  screenAnswer: function () {
    let thas = this;
    if (thas.data.subjects.length > thas.data.subjectNumber - 1) {
      for (let i = 0; i < thas.data.subjects[thas.data.subjectNumber - 1].itemList.length; i++) {
        let item = thas.data.subjects[thas.data.subjectNumber - 1].itemList[i];
        item.className = "zoomIn";
      }
      thas.setData({
        subjectItem: thas.data.subjects[thas.data.subjectNumber - 1]
      });
    }
    //切换题随机生产一个随机数
    if (thas.data.guestUser.isRobot == 1) {
      thas.setData({ robotRandom: app.robotRandom() + 2 });
    }
  },
  /* 提示信息*/
  tipsMessage:function(code,message){
    let thas=this;
    let abnormalCode={
      2045:'程序出了点差错  稍会再试',
      2046:'网络繁忙',
      2047:'网络繁忙',
      2049:'用户未授权',
      2050:'用户未在等待列表中',
      2051:'未配置当前关卡题目',
      2052:'房间人数错误',
      2053:'用户与房间不匹配',
      2054:'提交答案错误',
      2055:'网络繁忙',
      2056:'网络繁忙',
      2057:'房间用户错误',
      2058:'房间用户错误',
      1006:'网络繁忙',
    };
    try {
       wx.showModal({
        title: abnormalCode[code]||message||'程序出了点差错  稍会再试',
        content: '',
        showCancel: false,
        confirmText:'返回',
        confirmColor:'#42C18A',
        success: function (res) {
            thas.out();
        }
    });
    } catch (error) {
      console.log(error)
    }
  },
  /**选择答案 */
  selectAnswer: function (e) {
    let thas = this;

    console.log(thas.data.isSelect);
    console.log(thas.data.countNumber);
    console.log(e.currentTarget.dataset.isdisabled);

    if (e.currentTarget.dataset.isdisabled
      || !thas.data.isSelect
      || thas.data.countNumber == 0
      || !thas.data.isShowAnswer
      || thas.data.cutAnswerId == e.currentTarget.dataset.id) {
      return false;
    }
    thas.setData({
      isSelect: false,
    });

    //判断是否已经选择了
    if (thas.data.houseOwnerAnswerItem != null && thas.data.houseOwnerAnswerItem.userId == thas.data.serverUser.id) {
      return false;
    }
    if (thas.data.guestAnswerItem != null && thas.data.guestAnswerItem.userId == thas.data.serverUser.id) {
      return false;
    }
    console.log("选择答案时间：" + thas.data.countNumber);

    /*该题是不是正确答案 isCorrectStatus 1:正确，0:错误    预显示结果   添加已选答案 */
    try {
          let isCorrectStatus= e.currentTarget.dataset.iscorrect;
          let subjectLength=thas.data.subjectItem.itemList.length;//题目长度
          let subjectArr=thas.data.subjectItem;
          for (let i = 0; i < subjectLength; i++) {
            if(e.currentTarget.dataset.id===subjectArr.itemList[i].id){
                let item = subjectArr.itemList[i];
                    item.isAnswerMy = isCorrectStatus;
                    item.className = (isCorrectStatus==1 ? "pulse correct-bg" : "shake error-bg");
                    //播放匹配音效
                    if (wx.getStorageSync('isSound') == 1) {
                      if (isCorrectStatus==1) {
                        innerAudioContext.src = thas.data.MP3.correct;
                        innerAudioContext.play();
                      }
                      else {
                        innerAudioContext.src = thas.data.MP3.error;
                        innerAudioContext.play();
                      }
                    }
                }
            }
             thas.setData({
                subjectItem: subjectArr,
              });
    } catch (error) {
        console.log('预选择答案失败',error);
    }
    
    //跟机器人答题 我提交的答案
    if (thas.data.guestUser.isRobot == 1) {
      let msg = {
        isRobot: 0,
        userTime: thas.data.countNumber,
        answer: e.currentTarget.dataset.id,
        subject: thas.data.subjectItem.id,
        houseId: thas.data.houseId
      }
      console.log(msg);
      thas.send({ event: "robotAnswer", body: JSON.stringify(msg),userId:thas.data.serverUser.id });
      return false;
    }

    //发送答案
    let msg = {
      userTime: thas.data.countNumber,
      answer: e.currentTarget.dataset.id,
      subject: thas.data.subjectItem.id,
      houseId: thas.data.houseId
    }
    if(!thas.data.submited){
      thas.setData({submited:true});
      thas.send({ event: "submitAnswer", body: JSON.stringify(msg),userId:thas.data.serverUser.id });
    }

  },
  /**结束当前答题 -- 开始下一题 */
  endAnswer: function () {
    let thas = this;
    thas.setData({
      subjectNumber: thas.data.subjectNumber + 1,
      houseOwnerAnswerItem: null, //清空我方答案
      guestAnswerItem: null, //清空敌方答案
      submited:false,
    });
    timeout7 = setTimeout(() => {
      thas.screenAnswer();
    }, 500);
  },
  /**开启倒计时 */
  startInterval: function () {
    let thas = this;
    thas.countCanvasInterval(); //调用圆形倒计时
    clearInterval(thas.data.matchInterval); //清空定时器
    clearInterval(thas.data.interval);
    if (wx.getStorageSync('isSound') == 1) {
      //innerAudioContextTime.seek(0);
      innerAudioContextTime.play(); //播放倒计时
    }
    thas.setData({
      interval: setInterval(() => {
        thas.setData({
          isProp: true
        });
        //判断机器人随机提交
        //console.log("定时器：" + thas.data.countNumber);

        if (thas.data.guestUser.isRobot == 1 && thas.data.robotRandom == thas.data.countNumber) {
          let msg = {
            isRobot: 1,
            userTime: thas.data.countNumber,
            subject: thas.data.subjectItem.id,
            houseId: thas.data.houseId
          }
          thas.send({ event: "robotAnswer", body: JSON.stringify(msg),userId:thas.data.serverUser.id });
        }

        if (thas.data.countNumber == 0) {
          clearInterval(thas.data.matchInterval); //清空定时器
          clearInterval(thas.data.interval);
          clearInterval(thas.data.canvasInterval);
          if (wx.getStorageSync('isSound') == 1) {
            innerAudioContextTime.pause(); //暂停倒计时
          }
          if (thas.data.houseOwnerUser.isRobot == 0) {
            let msg = {
              subject: thas.data.subjectItem.id,
              houseId: thas.data.houseId
            }
            if (thas.data.serverUser.id == thas.data.houseOwnerUser.id) {
              //自己超时提交  submited 避免第二次提交
              if(!thas.data.submited){
                  thas.send({ event: "defaultSubmit", body: JSON.stringify(msg) ,userId:thas.data.serverUser.id});
              }
            }
            else {
              //对方超时提交
              thas.send({ event: "submitTimeOut", body: JSON.stringify(msg),userId:thas.data.serverUser.id });
            }
          }
        }
        else {
          thas.setData({
            countNumber: thas.data.countNumber - 1,
          });
        }
      }, 1000)
    });

  },
  //socket无响应方案  12s倒计时  退出 type  start   end   clear
  responseFun(type){
      let thas=this;
      console.log('调用responseFun',type)
      switch (type) {
        case 'start':
          responseTimeout=setTimeout(() => {
            console.log('网络异常  开始调用··················')
            thas.clearAll();
            socketOpen = false;
            wx.closeSocket();
            wx.showModal({
                  title: '网络异常',
                  showCancel: false,
                  confirmText:'确认',
                  confirmColor:'#42C18A',
                  success: function (res) {
                      thas.out();
                  }
              });
          }, responseTime);
          break;
        case 'end':
          clearTimeout(responseTimeout);
          break;
        default:
            break;
      }
  },
  /**关闭倒计时 */
  closeInterval: function () {
    let thas = this;
    clearInterval(thas.data.matchInterval); //清空定时器
    clearInterval(thas.data.interval);
    clearInterval(thas.data.canvasInterval);
    clearTimeout(contraryIsSubmitTimeout);
    if (wx.getStorageSync('isSound') == 1) {
      innerAudioContextTime.pause(); //暂停倒计时
      //innerAudioContextTime.seek(0);
    }
    thas.setData({
      isProp: false,
      submited:false,
    });
    timeout8 = setTimeout(() => {

      for (let i = 0; i < thas.data.subjectItem.itemList.length; i++) {
        let item = thas.data.subjectItem.itemList[i];
        item.className = "zoomOut";
      }

      thas.setData({
        answerClassName: "zoomOut",
        firstAnswer: "zoomOut",
        subjectItem: thas.data.subjectItem,
        isEndClassName: "zoomOut",
        // TODO 创可贴，排除卡，秒选卡，适用范围变更为每场比赛仅能用一次,如果每道题都是用解开注释即可
        // isProp1: false,
        // isProp2: false,
        // isProp3: false
      });
      thas.restoreCountInterval();

      timeout15 = setTimeout(() => {
        thas.setData({
          isShowAnswer: false,
          isFirstAnswer: false,
          isAnswerClassName: false,
          countNumber: 10, //恢复10秒
        });
      }, 200);

      thas.endAnswer();

      //表示最后一道题了
      if (thas.data.subjectNumber - 1 == thas.data.subjects.length - 1) {
        thas.setData({
          isEnd: true,
        });
      }
      //表示答题完成--显示答题结果
      if (thas.data.subjectNumber - 1 > thas.data.subjects.length - 1) {
        thas.clearAll();
        thas.setData({
          startAnswerIsShow: false,
          isResultShow: true,
          socketOpen: false,
        });

        //判断机器人不做提交
        if (thas.data.houseOwnerUser.isRobot == 0) {
          let msg = {
            houseId: thas.data.houseId
          }
          thas.send({ event: "finishedAnswer", body: JSON.stringify(msg) ,userId:thas.data.serverUser.id});
        }

      }
      else {
        timeout9 = setTimeout(() => {
          thas.setData({
            firstAnswer: "zoomIn",
            isFirstAnswer: true,
          });
          if (thas.data.isEnd) {
            thas.setData({
              isEndClassName: "zoomOut",
            });
          }
          timeout10 = setTimeout(() => {
            thas.setData({
              answerClassName: "zoomIn",
              isAnswerClassName: true
            });
            timeout11 = setTimeout(() => {
              //设置可选择答案状态
              thas.setData({
                isSelect: true,
                isShowAnswer: true
              });
              thas.startInterval();
            }, 1000);
          }, 1000);
        }, 1000);
      }
    }, 2000);

  },
  /**好友PK开始游戏 */
  gameStart: function () {
    let thas = this;
    if (!thas.data.isFriendsStart) {
      wx.showLoading({ title: '加载中', mask: true })
      thas.setData({
        isFriendsStart: true
      });
      thas.send({ event: "gameStart", body: this.data.houseId,userId:thas.data.serverUser.id });
      wx.hideLoading();
    }
  },
  /**放弃游戏 */
  giveUpGame: function () {
    let thas = this;
    let msg = {
      houseId: thas.data.houseId,
      houseOwner: thas.data.houseUserId
    }
    if(socketOpen){
      thas.send({ event: "giveUpGame", body: JSON.stringify(msg),userId:thas.data.serverUser.id });
    }else{
      thas.out();
    }

  },
  /**再来一局 */
  anotherGame: function () {
    let thas = this;
    app.http(app.api.goHouse, { friendId: thas.data.guestUser.id }, function (res) {

      if (res.data.code == 2036) {
        wx.redirectTo({
          url: '../battle/app?houseId=' + res.data.body + '&type=100',
        })
      }
      else {
        wx.redirectTo({
          url: "../battle/app?type=100"
        })
      }

    }, function () { }, false);
  },
  /**机器人继续 */
  robotPKContinue: function () {
    wx.redirectTo({
      url: "../battle/app?type=200"
    })
  },
  /**使用道具 */
  useProp: function (e) {
    let thas = this;
    if (!thas.data.isProp || thas.data.countNumber == 0) {
      return false;
    }
    switch (Number(e.currentTarget.dataset.type)) {
      //排除卡
      case 0:
        //判断是否已经选择了
        if (thas.data.houseOwnerAnswerItem != null && thas.data.houseOwnerAnswerItem.userId == thas.data.serverUser.id) {
          wx.showToast({ title: '您已经选择答案了', icon: "none", duration: 1000 });
        }
        else if (thas.data.prop[2].num <= 0) {
          wx.showToast({ title: '暂无排除卡', icon: "none", duration: 1000 });
        }
        else {
          if (!thas.data.isProp1) {
            thas.setData({
              isProp1: true
            });
            let msg = {
              propId: thas.data.prop[2].propId,
              subjectId: thas.data.subjectItem.id,
              houseId: thas.data.houseId,
            }
            thas.send({ event: "propUse", body: JSON.stringify(msg),userId:thas.data.serverUser.id });
          }
          else {
            wx.showToast({ title: '该道具每场比赛只能使用一次', icon: "none", duration: 1000 });
          }
        }
        break;
      //创口贴
      case 1:
        if (thas.data.guestAnswerItem != null) {
          wx.showToast({ title: '对方已经选择答案了', icon: "none", duration: 1000 });
        }
        else if (thas.data.prop[3].num <= 0) {
          wx.showToast({ title: '暂无创口贴', icon: "none", duration: 1000 });
        }
        else {
          if (!thas.data.isProp2) {
            thas.setData({
              isProp2: true
            });
            let msg = {
              propId: thas.data.prop[3].propId,
              subjectId: thas.data.subjectItem.id,
              houseId: thas.data.houseId,
            }
            thas.send({ event: "propUse", body: JSON.stringify(msg),userId:thas.data.serverUser.id });
          }
          else {
            wx.showToast({ title: '该道具每场比赛只能使用一次', icon: "none", duration: 1000 });
          }
        }
        break;
      //秒选卡
      case 2:
        //判断是否已经选择了 && 是否被遮住了
        let isBool = false;
        for (let i = 0; i < thas.data.subjectItem.itemList.length; i++) {
          let item = thas.data.subjectItem.itemList[i];
          if (item.id == thas.data.cutAnswerId && item.isCorrect == 1) {
            isBool = true;
            break;
          }
        }
        if (isBool) {
          wx.showToast({ title: '答案已被创口贴遮住了,无法使用秒选卡', icon: "none", duration: 1000 });
        }
        else {
          if (thas.data.houseOwnerAnswerItem != null && thas.data.houseOwnerAnswerItem.userId == thas.data.serverUser.id) {
            wx.showToast({ title: '您已经选择答案了', icon: "none", duration: 1000 });
          }
          else if (thas.data.prop[4].num <= 0) {
            wx.showToast({ title: '暂无秒选卡', icon: "none", duration: 1000 });
          }
          else {
            if (!thas.data.isProp3) {
              let useNumber = 1;

              if (new Date(wx.getStorageSync('useSecondSelection').useTime).getTime() == new Date(new Date().format("yyyy-MM-dd")).getTime()) {
                if (wx.getStorageSync('useSecondSelection').useNumber == 0
                  || wx.getStorageSync('useSecondSelection').useNumber == undefined) {
                  useNumber = 1;
                }
                else if (wx.getStorageSync('useSecondSelection').useNumber == 1) {
                  useNumber = 2;
                }
                else if (wx.getStorageSync('useSecondSelection').useNumber == 2) {
                  wx.showToast({ title: '每天只能使用两次秒选卡', icon: "none", duration: 1000 });
                  return;
                }
              }

              //记录使用时间
              wx.setStorage({
                key: "useSecondSelection",
                data: {
                  useTime: new Date().format("yyyy-MM-dd"),
                  useNumber: useNumber
                }
              })

              thas.setData({
                isProp3: true
              });
              let msg = {
                propId: thas.data.prop[4].propId,
                subjectId: thas.data.subjectItem.id,
                houseId: thas.data.houseId,
              }
              thas.send({ event: "propUse", body: JSON.stringify(msg),userId:thas.data.serverUser.id });
            }
            else {
              wx.showToast({ title: '该道具每场比赛只能使用一次', icon: "none", duration: 1000 });
            }
          }
        }
        break;
    }
  },

  /**断开链接 */
  close: function () {
    this.clearAll();
    socketOpen = false;

    wx.closeSocket();
    //监听关闭
    wx.onSocketClose(function (res) {
      // clearInterval(heartbeatSetinter); //清空定时器发送心跳
      console.log('WebSocket 已关闭！');
      // wx.showModal({
      //     title: '游戏退出',
      //     showCancel: false,
      //     success: function (res) {
      //       wx.navigateBack({ changed: true });//返回上一页
      //     }
      //   })
    })
  },
  /**清除所有的定时器 */
  clearAll: function () {
    clearInterval(this.data.matchInterval); //清空定时器
    clearInterval(this.data.interval);
    clearInterval(this.data.canvasInterval);
    clearTimeout(timeout1);
    clearTimeout(timeout2);
    clearTimeout(timeout3);
    clearTimeout(timeout4);
    clearTimeout(timeout5);
    clearTimeout(timeout6);
    clearTimeout(timeout7);
    clearTimeout(timeout8);
    clearTimeout(timeout9);
    clearTimeout(timeout10);
    clearTimeout(timeout11);
    clearTimeout(timeout12);
    clearTimeout(timeout13);
    clearTimeout(timeout14);
    clearTimeout(timeout15);
    innerAudioContextTime.pause(); //暂停倒计时
  },
  out: function () {
    let thas=this;

    /* 测试使用  */
    // thas.send({ event: "test", body: '',userId:thas.data.serverUser.id });
    /* 测试使用  */



    wx.navigateBack({ changed: true });//返回上一页  
  },

  /**绘制圆形 */
  drawCircle: function (step) {
    var windowWidth = wx.getSystemInfoSync().windowWidth;
    var poaitionX = wx.getSystemInfoSync().windowWidth / 2;
    var context = wx.createCanvasContext('canvasProgress');
    context.setLineWidth(6);
    context.setStrokeStyle("#FFA400");
    context.setLineCap('round')
    context.beginPath();
    context.arc(poaitionX, 35, 24, -Math.PI / 2, step * Math.PI - Math.PI / 2, true);
    context.stroke();
    context.draw()
  },
  /**绘制边框 */
  canvasProgressborder: function () {
    var windowWidth = wx.getSystemInfoSync().windowWidth;
    var poaitionX = wx.getSystemInfoSync().windowWidth / 2;
    var ctx = wx.createCanvasContext('canvasProgressborder')
    ctx.setLineWidth(10);// 设置圆环的宽度
    ctx.setStrokeStyle('#FFFFFF'); // 设置圆环的颜色
    ctx.setLineCap('round') // 设置圆环端点的形状
    ctx.beginPath();//开始一个新的路径
    ctx.arc(poaitionX, 35, 24, 0, 2 * Math.PI, true);
    ctx.stroke();//对当前路径进行描边
    ctx.draw();
  },
  /**开始倒计时 */
  countCanvasInterval: function () {
    clearInterval(this.data.canvasInterval);
    this.data.canvasInterval = setInterval(() => {
      if (this.data.canvasCount < 100) {
        this.drawCircle(this.data.canvasCount / (100 / 2))
        this.data.canvasCount++;
      }
      else if (this.data.canvasCount == 100) {
        this.drawCircle(1.9999);
        clearInterval(this.data.canvasInterval);
      }
      else {
        clearInterval(this.data.canvasInterval);
      }
    }, 100)
  },
  /**还原倒计时 */
  restoreCountInterval: function () {
    clearInterval(this.data.canvasInterval);
    this.data.canvasInterval = setInterval(() => {
      if (this.data.canvasCount > 0) {
        this.drawCircle(this.data.canvasCount / (100 / 2));
        this.data.canvasCount--;
      }
      else if (this.data.canvasCount == 0) {
        this.drawCircle(0.001);
        clearInterval(this.data.canvasInterval);
      }
    }, 10)
  },

})
