var app = getApp();
var mtabW;
var timeOut = null;
Page({
  data: {
    ipImg: app.ipImg,
    userInfo: {},
    height: app.globalData.windowHeight(),
    // tabs: ["好友排名", "全国排名", "各省排名", "省平均", "每日一星"],
     tabs: [ '本单位排行',"全国排行",'好友排行'],
    // tabs: ["好友排名", "全国排名", "各省排名"],
    activeIndex: 0,
    slideOffset: 0,
    tabW: 0,
    personData: null,
    friendsList: [], //好友列表
    provinceList: [],//省列表
    worldList: [],   //世界列表 或者全国排行
    averageList: [],   //省平均
    everydayList: [],   //每日一星
    companyList:[],  //本单位排行
    pageSize: 10,
    pageNo1: 1,
    pageNo2: 1,
    pageNo3: 1,
    pageNo4: 1,
    pageNo5: 1,
    countData: null,
    isShow2: false,
    isShow3: false,
    isShow4: false,
    isShow5: false,
    isLoader2: false,
    isLoader3: false,
    isLoader4: false,
    isLoader5: false,
    isLoader6: false,
    rank1: 0,
    rank2: 0,
    rank3: 0,
    rank4: 0,
    rank5: 0,
    rank6: 0,
    cityName: "",
  },
  //事件处理函数
  onLoad: function () {
    var thas = this;
    wx.getSystemInfo({
      success: function (res) {
        mtabW = res.windowWidth / 3;  //设置tab的宽度
        thas.setData({
          tabW: mtabW
        })
      }
    });

    thas.setData({
      userInfo: wx.getStorageSync('serverUser')
    });

  },
  tabClick: function (e) {
     console.log(e.currentTarget.id)
    var that = this;
    var idIndex = e.currentTarget.id;
    var offsetW = e.currentTarget.offsetLeft;  //2种方法获取距离文档左边有多少距离
    clearTimeout(timeOut);
    timeOut = setTimeout(() => {
      this.setData({
        activeIndex: idIndex,
        slideOffset: offsetW
      });
    }, 100);
  },
   /*
  flag
  0: 个人数据,2:好友排名,1:世界排名或全国排行,3:省排名 4:省平均排名 5:每日一星 6: 本单位排名
  */
  bindChange: function (e) {
    console.log(e.detail.current)
    if (e.detail.current == 0 && !this.data.isShow2) {
      this.getData(6);
      this.setData({
        isShow2: true,
      });
    }
    if (e.detail.current == 1 && !this.data.isShow3) {
      this.getData(1);
      this.setData({
        isShow3: true,
      });
    }
    if (e.detail.current == 2 && !this.data.isShow4) {
      this.getData(2);
      this.setData({
        isShow4: true,
      });
    }
    if (e.detail.current == 4 && !this.data.isShow5) {
      this.getData(5);
      this.setData({
        isShow5: true,
      });
    }
    var current = e.detail.current;
    // if ((current + 1) % 4 == 0) {

    // }
    var offsetW = current * mtabW;    //2种方法获取距离文档左边有多少距离
    clearTimeout(timeOut);
    timeOut = setTimeout(() => {
      this.setData({
        activeIndex: current,
        slideOffset: offsetW
      });
    }, 100);

  },
  /**分享 */
  onShareAppMessage: function (res) {
    return {
      title: '来来来，快来挑战我',
      path: '/pages/index/app',
    }
  },
  onShow: function () {
    if (this.data.friendsList.length == 0) {
      this.getData(6);
      this.setData({isShow2:true})
    }
  },
  /**下拉刷新 */
  onPullDownRefresh: function () {
    setTimeout(function () {
      wx.stopPullDownRefresh();
    }, 1000);
  },
  /**上拉加载 */
  /*
  flag
  0: 个人数据,2:好友排名,1:世界排名,3:省排名 4:省平均排名 5:每日一星 6: 本单位排名
  */
  onReachBottom: function (e) {
    console.log(e.currentTarget.dataset.type)
    if (e.currentTarget.dataset.type == 1) {
      this.setData({
        pageNo2: this.data.pageNo2 + 1
      });
      this.getData(1);
    }

    if (e.currentTarget.dataset.type == 6) {
      this.setData({
        pageNo1: this.data.pageNo1 + 1
      });
      this.getData(6);
    }

    if (e.currentTarget.dataset.type == 2) {
      this.setData({
        pageNo3: this.data.pageNo3 + 1
      });
      if (this.data.pageNo3 <= 20) {
        this.getData(2);
      }
    }

    if (e.currentTarget.dataset.type == 3) {
      this.setData({
        pageNo4: this.data.pageNo4 + 1
      });
      if (this.data.pageNo4 <= 20) {
        this.getData(4);
      }
    }

    if (e.currentTarget.dataset.type == 4) {
      this.setData({
        pageNo5: this.data.pageNo5 + 1
      });
      if (this.data.pageNo5 <= 20) {
        this.getData(5);
      }
    }

  },
  /**获取数据 */
  /*
  flag
  0: 个人数据,2:好友排名,1:世界排名或全国排行,3:省排名 4:省平均排名 5:每日一星 6: 本单位排名
  */
  getData: function (flag) {
    let thas = this;
    let page = 1;
    //世界
    if (flag == 1) {
      page = thas.data.pageNo2;
    }
    // 本单位排名
    if (flag == 6) {
      page = thas.data.pageNo1;
    }
    //好友排名
    if (flag == 2) {
      page = thas.data.pageNo3;
    }
    //省平均
    // if (flag == 4) {
    //   page = thas.data.pageNo4;
    // }
    // //每日一星
    // if (flag == 5) {
    //   page = thas.data.pageNo5;
    // } 
    app.http(app.api.countData, { 
      flag: flag,
      pageSize: thas.data.pageSize,
      pageNO: page
     }, function (res) {
       let dataList = res.data.body.users;
       if (flag == 1) {
         thas.setData({
           isLoader3: true,
           rank3: res.data.body.self.rank
         });
         if (dataList.length > 0) {
           thas.setData({
             worldList: thas.data.worldList.length == 0 ? dataList : thas.data.worldList.concat(dataList)
           })
         }
         else {
           thas.data.pageNo2--;
         }
         console.log('```````',flag,page)

       }
       if (flag == 2) {
         if(res.data.body&&res.data.body.self&&res.data.body.self.rank){
           thas.setData({ rank1: res.data.body.self.rank})
         }
         if (dataList.length > 0) {
           thas.setData({
             friendsList: thas.data.friendsList.length == 0 ? dataList : thas.data.friendsList.concat(dataList)
            //  friendsList: []
           });
         }
         else {
           thas.data.pageNo3--;
         }
       }
      //  if (flag == 3) {
      //    thas.setData({
      //      isLoader2: true,
      //      rank2: res.data.body.self.rank,
      //      cityName: res.data.body.self.cityName
      //    });
      //    if (dataList.length > 0) {
      //      thas.setData({
      //        provinceList: thas.data.provinceList.length == 0 ? dataList : thas.data.provinceList.concat(dataList)
      //      })
      //    }
      //    else {
      //      thas.data.pageNo3--;
      //    }
      //  }
      //  if (flag == 4) {
      //    thas.setData({
      //      isLoader4: true,
      //      rank4: res.data.body.self.rank,
      //      cityName2: res.data.body.self.cityName
      //    });
      //    if (dataList.length > 0) {
      //      thas.setData({
      //        averageList: thas.data.averageList.length == 0 ? dataList : thas.data.averageList.concat(dataList)
      //      })
      //    }
      //    else {
      //      thas.data.pageNo4--;
      //    }
      //  }
      //  if (flag == 5) {
      //    thas.setData({
      //      isLoader5: true,
      //      rank5: res.data.body.self.rank,
      //    });
      //    if (dataList.length > 0) {
      //      thas.setData({
      //        everydayList: thas.data.everydayList.length == 0 ? dataList : thas.data.everydayList.concat(dataList)
      //      })
      //    }
      //    else {
      //      thas.data.pageNo5--;
      //    }
      //  } 
       if (flag == 6) {
         thas.setData({
           isLoader6: true
         });
         if(res.data.body&&res.data.body.self&&res.data.body.self.rank){
           thas.setData({ rank6: res.data.body.self.rank})
         }
         if (dataList.length > 0) {
           thas.setData({
             companyList: thas.data.companyList.length == 0 ? dataList : thas.data.companyList.concat(dataList)
           });
         }
         else {
           thas.data.pageNo1--;
         }
       } 
    }, function () { }, true);
  }

})