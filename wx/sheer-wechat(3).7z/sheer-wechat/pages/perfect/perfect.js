// pages/perfect/perfect.js
//获取应用实例
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
     openId:'',
     code:'',//邀请码
     avatar:'',//头像地址，如果传参，则更新为此头像地址
     nickName:'',//呢称，如果传参，则更新为此昵称
     organizationId:'',//机构id
     organization:'',
     city:'',
     cityId:'',//城市id   顶层城市是没有为null
     bindUsers:'',//含有以上所有信息的object
     overtime:null,//请求服务器5s没有相应   关闭loading
     type:false,//是否通过用户中心点击头像进来   值为  editNickName
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let thas = this;
    if(options&&options.type=='editNickName'){
      thas.setData({type:true});
      wx.setNavigationBarTitle({
            title: '修改姓名',
          });
      app.http(app.api.getMeachName, {}, function(result) {
            let {organization,city}=result.data.body;
            thas.setData({bindUsers:{organization,city}});
          },function () {}, true)

    }else{
       let bindUsers=wx.getStorageSync('bindUsers');
       thas.setData({bindUsers:bindUsers});
    }
    console.log(thas.data);
    clearTimeout( thas.data.overtime); //清空定时器
  },
    /**监听页面卸载 */
  onUnload: function () {
    clearTimeout( this.data.overtime); //清空定时器
  },
  /**绑定用户信息 */
  bindUserInfo:function(){
      let thas = this;
      let {nickName}=thas.data;
      if(!nickName){ wx.showToast({ title: "请输入您的真实姓名",  icon: 'none',  duration: 1500 });return false};
      if (app.globalData.isEmoji.test(nickName)) {
       try {
          wx.hideToast();
          wx.showToast({ title: "不支持表情", icon: 'none', duration: 1500 });
       } catch (error) {
         console.log(error)
       }
        return false;
      }
      wx.showLoading({ title: '加载中', mask: true });


      /*10S 没有相应关闭loading */
      thas.data.overtime=setTimeout(() => {
        wx.hideLoading();
      }, 10000);

      /* type  存在即为修改用户昵称  否则为绑定用户信息*/
      if(thas.data.type){
          console.log('修改用户昵称');
        app.http(app.api.editNickName, { nickName:nickName}, function(result) {
              /***修改成功返回上一页 */
              // console.log(result)
              try{
                let userInfo = wx.getStorageSync('serverUser');
                userInfo.nickName = nickName;
                wx.setStorageSync('serverUser', userInfo);
              }catch(e){console.log(e)}
              wx.navigateBack({ changed: true });
          },function () {}, true)
         
      }else{
        thas.bindUser();
      }
  },
   /**监听输入真实姓名 */
  watchInput: function (event) {
    this.setData({
      nickName: event.detail.value,
    })
  },
  //绑定用户信息 
  bindUser:function(){
     let thas = this;
     let {nickName}=thas.data;
     let  {openId,code,avatar,organizationId,cityId}=thas.data.bindUsers,userInfo={openId,code,avatar,organizationId};//将要绑定用户信息 userInfo  cityId为顶层时值为null  不传
     if(cityId!==null){ userInfo.cityId=cityId};
      userInfo.nickName=nickName;
      app.http(app.api.bindOpenId, userInfo, function(result) {
            console.log(result, 'eqeqe````````');
              wx.hideLoading();
              wx.setStorage({
                  key: "isShowNotice",
                  data: {
                      time: new Date().format("yyyy-MM-dd")
                  }
              })

              wx.setStorage({
                  key: "isSound",
                  data: result.data.body.isSound
              })
              // if (wx.getStorageSync('isSound') == 1) {
              //     innerAudioContext.play();
              // }

              app.globalData.isBind = false;
              app.token = result.data.body.token;

              wx.setStorage({
                  key: "serverUser",
                  data: result.data.body
              })
               wx.reLaunch({
                    url: './../index/app',
                    fail:function() {
                      console.log('调用wx.reLaunch出错了');
                        wx.navigateTo({
                          url: './../index/app',
                      })
                    }
                })
          },function () { }, true)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})