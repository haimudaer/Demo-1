// pages/index1/detail.js
//获取应用实例
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:"",//详情id
    detailInfo:'',//详情纤细
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options.id)
    this.setData({
      id: options.id,
    });
    this.getDetailInfo();//获取详情数据
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },
  // 获取详情数据
  getDetailInfo:function(){
    var that = this;
    wx.request({
      url: app.ip + app.api.getNewDetail + '/' + that.data.id,
      // url: "http://192.168.1.111:8022/api/news/get/" + that.data.id,
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        console.log(res.data)
        if(res.data.code == 200 && res.data.status == true){
          that.setData({
            detailInfo:res.data.body
          })
        }
      }
    })

  }
})