// pages/teamChallenge/record.js
var app = getApp();
Page({

  /*** 页面的初始数据*/
  data: {
    ipImg: app.ipImg,
    userInfo: '',//登录用户信息
    scheduleId: '',//赛程id
    myTeamId:'',//登录用户所在的团队id
    soure:0,//页面来源 0：历史来源  1:比赛结束

    status: 0,// -1：负 0：平局 1：赢
    myTeamInfo: null,//登录用户所在战队
    opponentTeamInfo:null,//对手战队
    teamPersonList:[],//参赛人员列表

    isShareResult: null, //是否分享结果
    shareOnceStatus: true,//新增当前页面只能分享一次获得20经验

  },

  /*** 生命周期函数--监听页面加载*/
  onLoad: function (options) {
    this.setData({
      scheduleId: options.id,
      myTeamId: options.teamId,
      soure:options.type,
      userInfo: wx.getStorageSync('serverUser'),
    })
    // 获取赛程团队战绩信息
    this.getTeamWarScore();
  },
  // 页面卸载
  onUnload:function(){},
  // 获取赛程团队战绩信息
  getTeamWarScore(){
    let _this = this;
    let path = (_this.data.soure == 0 ? app.api.scheduleHistory : app.api.teamWarScore);
    wx.request({
      url: app.ip + path,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data: {
        scheduleId: _this.data.scheduleId,
        token: app.token,
        teamId:_this.data.myTeamId
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          let body = res.data.body;
          body.teamA.victory = Math.floor(body.teamA.victory * 100) / 100;;
          body.teamB.victory = Math.floor(body.teamB.victory * 100) / 100;;

          for(var i = 0; i<body.teamA.userVoList.length;i++){
            let item = body.teamA.userVoList[i];
            item.contribution = parseInt(item.contribution);
          }

          _this.setData({
            myTeamInfo:body.teamA,
            opponentTeamInfo:body.teamB,
            status:body.status,
            teamPersonList: body.teamA.userVoList
          })
        }
      },
      fail(error) {
        console.log(`获取我的赛程失败`, error);
      }
    })
  },

  /**分享--挑战 */
  onShareAppMessage: function (e) {
    let thas = this;
    let title = "快来看看我，惊不惊喜！意不意外！";
    let path = "/pages/index/app";
   
    //只能第一次分享获取经验
    if (thas.data.shareOnceStatus) {
      app.http(app.api.addScore, { flag: 0 }, function (res) {
        thas.setData({
          isShareResult: 1,
          shareOnceStatus: false
        });
      }, function () { }, true);
    };
    return {
      title: title,
      path: path,
      //imageUrl: this.data.ipImg + "meun-3.png",
      success: function () {
        if (thas.data.isShareResult == null) {
          app.http(app.api.addScore, { flag: 0 }, function (res) {
            thas.setData({
              isShareResult: 1
            });
          }, function () { }, true);
        }
      },
      fail: function () {
        console.log("失败回调..");
      }
    }
  },
})