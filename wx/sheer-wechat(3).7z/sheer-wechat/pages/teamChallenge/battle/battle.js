// pages/teamChallenge/battle.js
const app = getApp();
//媒体播放
const innerAudioContext = wx.createInnerAudioContext();
const innerAudioContextTime = wx.createInnerAudioContext(); //倒计时
var utils = require('../../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ipImg: app.ipImg,

    headTimer:null,
    headTimer1: null, //头部比赛倒计时
    heartbeatSetinter: null,
    heartbeatTime: 4000, //定时向socket  发送心跳  5s
    answerSetinter : null, //答题倒计时
    isEndProcess : false, //是否结束进程

    total: 1800, //赛程总时长 不设置也可以
    minute: '', //分
    second: '', //秒
    widthSli: "100%",

    isNetWorkTimeOut: false, //是否网络超时

    screen: false, //场景打开

    scheduleId: '', //赛程id
    serverUser: '', //登录用户信息
    houseId: '', //房间id
    matchOpponentNumber: 60, //匹配对手时间 1min

    isMatchOpponent: false, //是否匹配到对手
    isCancelMatch: false, //是否手动取消匹配
    isAutoCacel: false,//是否自动退出

    opponentInfo: null, //匹配成功后的对手信息

    bounchLeftClass: "bounceInLeft", //左边动画
    bounchRightClass: "bounceInRight", //右边动画
    zoomClass: "zoomIn",

    totalScore: 1200, //题目总分
    subjectList: [], //题目列表
    subjectItem: [], //当前答题对象
    subjectItemId:null,//当前题目Id
    subjectNumber: 1, //当前达第几道题 从1开始
    answerTimer: 10, //每道题的答题时间

    isAnswerOvertime: false, //答题(每一题)是否超时
    canvasCount: 0, //canvas倒计时

    isStartAnswer: false, //是否开始答题

    isLastAnswer: false, //是否最后一道题
    isOverAnswer: false, //是否答题结束
    isEndclassName: 'zoomIn', //最后一题样式
    isEndMatchTime: false, //比赛时间是否结束

    ownerAnswerId: null, //我选的答案
    guestAnswerId: null, //敌人的答案

    ownerScore: 0, //我方分数
    guestScore: 0, //他方分数
    ownerHeight: 0, //我方百分比
    guestHeight: 0, //敌方百分比


    ownerCount: null, //我方场次统计
    guestCount: null, //对手方场次统计
    //音效路径
    MP3: {
      match: app.ipImg + "match.mp3",
      success: app.ipImg + "success.wav",
      correct: app.ipImg + "correct.mp3",
      error: app.ipImg + "error_.mp3",
      time: app.ipImg + "time.mp3",
    },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let _this = this;
    // 清除所有计时器
    _this.closeAllTimer();
    this.setData({
      scheduleId: options.id,
      serverUser: wx.getStorageSync('serverUser'),
    })
    // 开始匹配
    _this.matchStart();
    
  },

  /** * 生命周期函数--监听页面初次渲染完成 */
  onReady: function() {
    this.canvasProgressborder();

    innerAudioContext.src = this.data.MP3.match;
    innerAudioContextTime.src = this.data.MP3.time;
    innerAudioContextTime.loop = true;
    innerAudioContext.onPlay(() => {
      console.log('开始播放')
    })

    innerAudioContext.onPause(() => {
      console.log('暂停播放')
    })


  },
  /*** 生命周期函数--监听页面显示*/
  onShow: function () {
    let _this = this;
    _this.closeAllTimer();
    // 执行心跳过程
    _this.matchHeader();
    //获取赛程倒计时方法
    _this.getLastTime();
    _this.setData({
      isEndProcess:false,
      headTimer: setInterval( () => {
        _this.getLastTime(); //获取赛程倒计时方法
      }, 120000)
    })
  },
  /*** 生命周期函数--监听页面隐藏*/
  onHide: function() {
    let _this = this;
    this.closeAllTimer();
    // 结束进程设置为true
    this.setData({ isEndProcess: true })
    //清除倒计时动画
    // this.restoreCountInterval();
    // 手动取消匹配为false 并且未匹配成功
    if (!this.data.isCancelMatch && !this.data.isMatchOpponent) {
      this.giveMatch(); //取消匹配
    }
    // 开始答题&&答题未结束&&赛程时间未到&&网络未超时
    if (this.data.isStartAnswer && !this.data.isOverAnswer && !this.data.isNetWorkTimeOut) {
      wx.navigateBack(); //返回上一页
    }
   },
  /** * 生命周期函数--监听页面卸载 */
  onUnload: function () {
    this.closeAllTimer();
    // 结束进程设置为true
    this.setData({ isEndProcess: true })
    //清除倒计时动画
    // this.restoreCountInterval();
    // 手动取消匹配为false 并且未匹配成功
    if (!this.data.isCancelMatch && !this.data.isMatchOpponent) {
      this.setData({ isAutoCacel:true});//自动退出设置为true
      this.giveMatch(); //取消匹配
    }
    // 开始答题&&答题未结束&&赛程时间未到&&网络未超时
    if (this.data.isStartAnswer && !this.data.isOverAnswer && !this.data.isNetWorkTimeOut) {
      wx.showModal({
        title: "中途退出",
        showCancel: false,
        success: function(res) {}
      })
    }
  },
  // 执行心跳过程
  matchHeader() {
    let _this = this;
    _this.setData({
      heartbeatSetinter: setInterval(() => {
        wx.request({
          url: app.ip + app.api.teamKeepAlive,
          method: 'GET',
          header: {
            'content-type': 'application/json',
            'token': app.token,
          },
          data: {
            token: app.token
          },
          success(res) {
            if (res.data.code != 0) {

            }
          },
          fail(error) {
            //清除计时器
            _this.closeAllTimer();
            wx.showModal({
              title: "网络异常",
              showCancel: false,
              success: function (res) {
                _this.setData({
                  isNetWorkTimeOut: true
                });
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  }); //返回上一页
                }
              }
            })

          }
        })
      }, _this.data.heartbeatTime)
    })
  },
  // 开始匹配
  matchStart() {
    let _this = this;
    // 60s后取消匹配
    if (_this.data.matchOpponentNumber == 0) {
      //清除计时器
      _this.closeAllTimer();
      wx.showModal({
        title: "未匹配到对手",
        showCancel: false,
        success: function(res) {
          if (res.confirm) {
            _this.giveMatch(); //取消匹配
          }
        }
      })
    } else {
      _this.setData({
        matchOpponentNumber: _this.data.matchOpponentNumber - 1
      })
      wx.request({
        url: app.ip + app.api.matchStart,
        method: 'GET',
        header: {
          'content-type': 'application/json',
          'token': app.token,
        },
        data: {
          scheduleId: _this.data.scheduleId,
          token: app.token
        },
        success(res) {
          if (res.data.code == 200 && res.data.status == true) {
            _this.setData({
              isMatchOpponent: true, //匹配成功对手
              houseId: res.data.body.homeNo, //房间号
              opponentInfo: res.data.body.frontUser, //匹配成功后的对手信息
              subjectList: res.data.body.subjectList, //题目列表
            })
            //播放匹配音效
            if (!_this.data.isEndProcess && wx.getStorageSync('isSound') == 1) {
              innerAudioContext.play();
            }

            setTimeout(function() {
              _this.setData({
                bounchLeftClass: "bounceOutLeft",
                bounchRightClass: "bounceOutRight",
                zoomClass: "zoomOut",
              })
              //播放匹配音效
              if (wx.getStorageSync('isSound') == 1) {
                innerAudioContextTime.pause(); //暂停倒计时
              }
              setTimeout(function() {
                _this.screenAnswer(); //调用筛选题目
              }, 500);
            }, 2000);
          } else if (res.data.code == 303) {
              wx.navigateBack({ delta: 1  }); //返回上一页
          } else if (res.data.code == 304) {
            // 开始匹配
            setTimeout(function() {
              if (!_this.data.isEndProcess && !_this.data.isEndMatchTime){
                _this.matchStart();
              }
            }, 1000)
          }
        },
        fail(error) {}
      })
    }
  },
  // 取消匹配
  giveMatch() {
    let _this = this;
    wx.request({
      url: app.ip + app.api.matchCacel,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data: {
        scheduleId: _this.data.scheduleId,
        token: app.token
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          _this.setData({
            isCancelMatch: true
          }); //手动取消比赛设置为true
          _this.closeAllTimer(); //关闭所有计时器
          if (!_this.data.isAutoCacel){
            wx.navigateBack({ delta: 1 }); //返回上一页
          }
        }
      },
      fail(error) {}
    })
  },
  // 筛选题目
  screenAnswer() {
    let _this = this;
    if (_this.data.subjectList.length > _this.data.subjectNumber - 1) {
      for (let i = 0; i < _this.data.subjectList[_this.data.subjectNumber - 1].itemList.length; i++) {
        let item = _this.data.subjectList[_this.data.subjectNumber - 1].itemList[i];
        item.className = "zoomIn";
        item.isDisabled = 0;
        item.guestclassName = "";
        item.correctClassName = "";
      }
      
      _this.setData({
        isStartAnswer: true,
        subjectItem: _this.data.subjectList[_this.data.subjectNumber - 1],
        zoomClass: "zoomIn",
        bounchLeftClass: "bounceInLeft",
        bounchRightClass: "bounceInRight",
        answerTimer: 10,
        subjectItemId:null,//当前题目答案
        ownerAnswerId: null, //我选的答案
        guestAnswerId: null, //敌人的答案
        isLastAnswer: (_this.data.subjectList.length - 1 == _this.data.subjectNumber - 1) ? true : false,
      });
      _this.answerTimer();
    }
  },
  //答题倒计时
  answerTimer() {
    let _this = this;
    if (!_this.data.isEndProcess) {
      _this.drawCircle(2);
      _this.countCanvasInterval(); //调用圆形倒计时
    }
    if (!_this.data.isEndProcess && wx.getStorageSync('isSound') == 1) {
      innerAudioContextTime.play(); //播放倒计时
    }
    _this.setData({
      isAnswerOvertime: false
    }) //代表答题超时
    _this.setData({
      answerSetinter: setInterval(() => {
        if (_this.data.answerTimer == 0) {
          //清除超时倒计时
          clearInterval(_this.data.answerSetinter);
          //重置倒计时动画
          _this.restoreCountInterval();
          // 设置倒计时超时
          _this.setData({
            isAnswerOvertime: true,
          })
          // 未答题时调用超时接口
          if (_this.data.ownerAnswerId == null && !_this.data.isEndProcess) {
            _this.answerOverTime(); // 答题超时
          }
        } else {
          _this.setData({
            answerTimer: _this.data.answerTimer - 1,
          })
        }
      }, 1000)
    })
  },
  // 选择答题
  selectAnswer(e) {
    let _this = this;
    // 答题倒计时 未超时/当前选项可以选择/当前用户未选中信息
    if (_this.data.isAnswerOvertime == false && _this.data.subjectItemId != e.currentTarget.dataset.subjectid && e.currentTarget.dataset.isdisabled == 0 && _this.data.ownerAnswerId == null) {

      let isCorrectStatus = e.currentTarget.dataset.iscorrect; //选择的选项正确：1.正确  0.不正确
      let subjectArr = _this.data.subjectItem; //当前题目

      _this.setData({ subjectItemId: e.currentTarget.dataset.subjectid }); //设置当前题目如果选中则设置到subjectItemId中

      for (let i = 0; i < subjectArr.itemList.length; i++) {
        subjectArr.itemList[i].isDisabled = 1;
      }
      _this.setData({
        subjectItem: subjectArr,
      });


      app.http(app.api.teamAnswer, {
        scheduleId: _this.data.scheduleId,
        teamId: _this.data.serverUser.teamId,
        homeNo: _this.data.houseId,
        userId: _this.data.serverUser.id,
        subjectId: _this.data.subjectItem.id,
        answerId: e.currentTarget.dataset.id,
        userTime: (10 - _this.data.answerTimer)
      }, function(res) {
        let score = (res.data.body.score == null ? 0 : res.data.body.score);
        let answer = res.data.body.answer;

        if (answer != null) {
          for (let i = 0; i < subjectArr.itemList.length; i++) {
            subjectArr.itemList[i].isDisabled = 1;
            if (answer === subjectArr.itemList[i].id) {
              let item = subjectArr.itemList[i];
              item.isAnswerMy = isCorrectStatus;
              item.className = (isCorrectStatus == 1 ? "pulse correct-bg" : "shake error-bg");
              //播放匹配音效
              if (wx.getStorageSync('isSound') == 1) {
                if (isCorrectStatus == 1) {
                  innerAudioContext.src = _this.data.MP3.correct;
                  innerAudioContext.play();
                }
                else {
                  innerAudioContext.src = _this.data.MP3.error;
                  innerAudioContext.play();
                }
              }
            }
          }
          _this.setData({
            subjectItem: subjectArr,
          });
        }

        _this.setData({
          ownerScore: _this.data.ownerScore + score,
          ownerHeight: ((_this.data.ownerScore + score) / _this.data.totalScore * 100).toFixed(2),
          ownerAnswerId: answer,
        })
        if (!_this.data.isEndProcess && !_this.data.isAnswerOvertime) {
          _this.getNextAnswer();
        }
      }, function() {}, true)

    }
  },
  // 答题超时
  answerOverTime() {
    let _this = this;
    app.http(app.api.teamTimeOut, {
      scheduleId: _this.data.scheduleId,
      teamId: _this.data.serverUser.teamId,
      homeNo: _this.data.houseId,
      userId: _this.data.serverUser.id,
      subjectId: _this.data.subjectItem.id,
      userTime: 10
    }, function(res) {
      _this.setData({
        ownerScore: _this.data.ownerScore + res.data.body.score,
        ownerHeight: ((_this.data.ownerScore + res.data.body.score) / _this.data.totalScore * 100).toFixed(2)
      })
      _this.getNextAnswer(); //判断能否进入下一题
    }, function() {}, true)
  },
  // 查看能否进入到下一题
  getNextAnswer() {
    let _this = this;
    let nextSubjectId = "isFinished";
    if (_this.data.subjectList.length !== _this.data.subjectNumber) {
      nextSubjectId = _this.data.subjectList[_this.data.subjectNumber].id;
    }
    wx.request({
      url: app.ip + app.api.isSubjectNext,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data: {
        scheduleId: _this.data.scheduleId,
        teamId: _this.data.serverUser.teamId,
        homeNo: _this.data.houseId,
        userId: _this.data.serverUser.id,
        subjectId: _this.data.subjectItem.id,
        nextSubjectId: nextSubjectId
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          let userAnswer = res.data.body.userAnswer;
          if (res.data.body.canNext == false) {
            setTimeout(function(){
              if (!_this.data.isEndProcess) {
                _this.getNextAnswer();
              }
            },1000)
          } else {
            clearInterval(_this.data.answerSetinter); //清除倒计时
            _this.restoreCountInterval(); //重置倒计时动画
            if (wx.getStorageSync('isSound') == 1) {
              innerAudioContextTime.pause(); //暂停倒计时
            }
            let score = (userAnswer.score == null ? 0 : userAnswer.score);

            _this.setData({
              guestAnswerId: userAnswer.answer,
              guestScore: _this.data.guestScore + score,
              guestHeight: ((_this.data.guestScore + score) / _this.data.totalScore * 100).toFixed(2),
            })
            let subjectArr = _this.data.subjectItem; //当前题目

            for (let i = 0; i < subjectArr.itemList.length; i++) {
              let item = subjectArr.itemList[i];

              if (item.isCorrect) {
                item.className = "";
                item.correctClassName = "pulse correct-bg";
              }
              if (_this.data.guestAnswerId === item.id) {

                item.isAnswerTo = item.isCorrect;
                item.className = "";
                item.guestclassName = (item.isCorrect == 1 ? "pulse correct-bg" : "shake error-bg");
              }
            }
            _this.setData({
              subjectItem: subjectArr,
            });

            // 设置下一题
            _this.setNextQuestion();
          }

        }
      },
      fail(error) {}
    })
  },
  // 设置下一题
  setNextQuestion() {
    let _this = this;
    setTimeout(() => {
      _this.setData({
        zoomClass: "zoomOut",
      })
      //如果打的是最后一道题
      if (_this.data.subjectList.length - 1 === _this.data.subjectNumber - 1) {
        //清除计时器
        clearInterval(_this.data.heartbeatSetinter);
        _this.setData({
          zoomClass: "zoomOut",
        })
        setTimeout(() => {
          _this.setData({
            isOverAnswer: true, //是否答题结束
          })
        }, 200)
        _this.getTeamUserScore(); //获取团队统计结果
      } else {
        _this.setData({
          subjectNumber: _this.data.subjectNumber + 1,
          zoomClass: "zoomOut",
        })

        setTimeout(() => {
          _this.setData({
            subjectItem: [],
            subjectItemId:null,// 当前所答题的题ID
            ownerAnswerId: null, //我选的答案
            guestAnswerId: null, //敌人的答案
          })
          _this.screenAnswer(); //调用筛选题目
        }, 500)
      }
    }, 1500)

  },
  //获取团队统计结果
  getTeamUserScore() {
    let _this = this;
    wx.request({
      url: app.ip + app.api.teamUserScore,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data: {
        scheduleId: _this.data.scheduleId,
        teamId: _this.data.serverUser.teamId,
        homeNo: _this.data.houseId,
        userId: _this.data.serverUser.id,
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          let body = res.data.body;
          if (body[0].teamId === _this.data.serverUser.teamId) {
            _this.setData({
              ownerCount: body[0],
              guestCount: body[1]
            })
          } else {
            _this.setData({
              ownerCount: body[1],
              guestCount: body[0]
            })
          }

          //播放匹配音效
          if (wx.getStorageSync('isSound') == 1 && _this.data.ownerCount && _this.data.guestCount && _this.data.ownerCount.score > _this.data.guestCount.score) {
            innerAudioContext.src = _this.data.MP3.success;
            innerAudioContext.play();
          }


        } else if (res.data.code == 9527) {
          _this.getTeamUserScore(); //获取团队统计结果
        }
      },
      fail(error) {}
    })
  },

  // 获取赛程倒计时
  getLastTime() {
    let _this = this;
    wx.request({
      url: app.ip + app.api.getLastTime,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data: {
        scheduleId: _this.data.scheduleId,
        token: app.token
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          var body = res.data.body;
          clearInterval(_this.data.headTimer1);
          _this.setData({
            total: res.data.body,
          })
          _this.caculate(); //计算
        }
      },
      fail(error) {}
    })
  },
  // 计算
  caculate() {
    var _this = this;
    _this.setData({
      headTimer1: setInterval(() => {
        if (_this.data.total <= 0) {
          clearInterval(_this.data.headTimer); //清除头部计时器
          clearInterval(_this.data.headTimer1); //清除头部计时器
          _this.setData({ isEndMatchTime: true });
          // 手动取消匹配为false 并且未匹配成功
          if (!this.data.isCancelMatch && !this.data.isMatchOpponent) {
            _this.giveMatch(); //取消匹配
          }
        } else {
          var totalSec = _this.data.total - 1;
          var minute = parseInt(totalSec / 60);
          var second = parseInt(totalSec % 60);
          _this.setData({
            total: totalSec,
            minute: utils.formatNumber(minute),
            second: utils.formatNumber(second),
            widthSli: (totalSec / 1800).toFixed(2) * 100
          })
        }
      }, 1000)
    })
  },
  //关闭所有计时器
  closeAllTimer() {
    clearInterval(this.data.answerSetinter); //清除超时倒计时
    clearInterval(this.data.heartbeatSetinter); //清除心跳
    clearInterval(this.data.headTimer); //清除头部计时器
    clearInterval(this.data.headTimer1); //清除头部计时器
    innerAudioContextTime.pause(); //暂停倒计时
    clearInterval(this.data.canvasInterval);//清除倒计时动画
  },
  // 挑战下一人
  out() {
    this.closeAllTimer();
    wx.navigateBack();
  },
  
  /**绘制边框 */
  canvasProgressborder: function () {
    var windowWidth = wx.getSystemInfoSync().windowWidth;
    var poaitionX = wx.getSystemInfoSync().windowWidth / 2;
    var ctx = wx.createCanvasContext('canvasProgressborder')
    ctx.setLineWidth(10);// 设置圆环的宽度
    ctx.setStrokeStyle('#FFFFFF'); // 设置圆环的颜色
    ctx.setLineCap('round') // 设置圆环端点的形状
    ctx.beginPath();//开始一个新的路径
    ctx.arc(poaitionX, 30, 25, 0, 2 * Math.PI, true);
    ctx.stroke();//对当前路径进行描边
    ctx.draw();
  },
  /**绘制圆形 */
  drawCircle: function (step) {
    var windowWidth = wx.getSystemInfoSync().windowWidth;
    var poaitionX = wx.getSystemInfoSync().windowWidth / 2;
    var context = wx.createCanvasContext('canvasProgress');
    context.setLineWidth(6);
    context.setStrokeStyle("#FFA400");
    context.setLineCap('round')
    context.beginPath();
    // 参数step 为绘制的圆环周长，从0到2为一周 。 -Math.PI / 2 将起始角设在12点钟位置 ，结束角 通过改变 step 的值确定
    context.arc(poaitionX, 30, 25, -Math.PI / 2, step * Math.PI - Math.PI / 2, true);
    context.stroke();
    context.draw()
  },
  /**开始倒计时 */
  countCanvasInterval: function () {
    clearInterval(this.data.canvasInterval);
    this.data.canvasInterval = setInterval(() => {
      if (this.data.canvasCount < 100) {
        this.drawCircle(this.data.canvasCount / (100 / 2))
        this.data.canvasCount++;
      }
      else if (this.data.canvasCount == 100) {
        this.drawCircle(1.9999);
        clearInterval(this.data.canvasInterval);
      }
      else {
        clearInterval(this.data.canvasInterval);
      }
    }, 100)
  },
  /**还原倒计时 */
  restoreCountInterval: function () {
    this.setData({ canvasCount: 0 });
    clearInterval(this.data.canvasInterval);
    // this.drawCircle(2);
    // this.data.canvasInterval = setInterval(() => {
    //   console.log(this.data.canvasCount)
    //   if (this.data.canvasCount > 0) {
    //     this.drawCircle(this.data.canvasCount / (100 / 2));
    //     this.data.canvasCount--;
    //   }
    //   else if (this.data.canvasCount == 0) {
    //     this.drawCircle(0.001);
    //     clearInterval(this.data.canvasInterval);
    //   }
    // }, 10)
  },

})