// pages/teamChallenge/waiting.js
var app = getApp();
var utils = require('../../../utils/util.js');
Page({

  /*** 页面的初始数据 */
  data: {
    ipImg: app.ipImg,
    headTimer: null, //头部比赛倒计时
    headTimer1: null,//头部比赛倒计时
    isEndProcess: false,//是否结束进程

    total: 1800,//赛程总时长 不设置也可以
    minute: '', //分
    second: '',//秒
    widthSli: "100%",

    userInfo:'',//登录用户信息
    scheduleId:'',//赛程id
    myTeamName:'',//我的团队
    myTeamList: [],//我的团队列表

    opponentTeamName:'',//对手团队
    opponentTeamList: [],//对手团队列表
  },

  /*** 生命周期函数--监听页面加载*/
  onLoad: function (options) {
    this.setData({
      scheduleId:options.id,
      userId:'',//当前登录用户id
      userInfo: wx.getStorageSync('serverUser'),
    })

  },
  /** * 生命周期函数--监听页面初次渲染完成 */
  onReady:function(){
   
  },
  /*** 生命周期函数--监听页面显示*/
  onShow: function () {
    let _this = this;
    _this.setData({
      isEndProcess: false,//未结束进程
    })
    // 获取赛程的团队信息
    _this.getCurrentGameInfo();
    //获取赛程倒计时方法
    _this.getLastTime();
    _this.setData({
      headTimer: setInterval(() => {
        _this.getLastTime();//获取赛程倒计时方法
      }, 120000)
    })
  },
  /*** 生命周期函数--监听页面隐藏*/
  onHide: function () {
    this.setData({
      isEndProcess: true,//未结束进程
    })
    this.closeAllTimer(); //关闭所有计时器
  },
  /*** 生命周期函数--监听页面卸载 */
  onUnload: function () {
    this.setData({
      isEndProcess: true,//未结束进程
    })
    this.closeAllTimer(); //关闭所有计时器
  },
  // 获取赛程的团队信息
  getCurrentGameInfo(){
    let _this = this;
    wx.request({
      url: app.ip + app.api.getCurrentGameInfo,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data:{
        scheduleId: _this.data.scheduleId,
        token:app.token
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          _this.setData({
            userId:res.data.body.userId,
            myTeamName: res.data.body.myTeamName,
            opponentTeamName: res.data.body.frontTeamName,
            myTeamList: res.data.body.myTeamUserList ? res.data.body.myTeamUserList : [],
            opponentTeamList: res.data.body.frontTeamUserList ? res.data.body.frontTeamUserList : [],
          })
        }
      },
      fail(error) {
        //清除计时器
        _this.closeAllTimer();
        wx.showModal({
          title: "网络异常",
          showCancel: false,
          success: function (res) {
            if (res.confirm) {
              wx.navigateBack({ delta: 1 });//返回上一页
            }
          }
        })

      }
    })
  },
  // 获取赛程倒计时
  getLastTime() {
    let _this = this; 
    if (!_this.data.isEndProcess) {
      wx.request({
        url: app.ip + app.api.getLastTime,
        method: 'GET',
        header: {
          'content-type': 'application/json',
          'token': app.token,
        },
        data: {
          scheduleId: _this.data.scheduleId,
          token: app.token
        },
        success(res) {
          if (res.data.code == 200 && res.data.status == true) {
            var body = res.data.body;
            clearInterval(_this.data.headTimer1);
            _this.setData({
              total: parseInt(res.data.body)
            })
            _this.caculate();//计算
          }
        },
        fail(error) {
          console.log(`获取赛程倒计时失败`, error);
        }
      })
    }
  },
  // 开始匹配
  startMatch(){
    if(this.data.total <= 0 ) return false;
    wx.navigateTo({
      url: '../battle/battle?id=' + this.data.scheduleId,
    })
  },
  // 计算
  caculate() {
    var _this = this;
    _this.setData({
      headTimer1 : setInterval(() => {
        var minute = 0;
        var second = 0;
        var widthSli = 0;
        // 超时90S执行
        if (_this.data.total <= -90) {
          _this.closeAllTimer(); //关闭所有计时器
          _this.setData({
            isEndProcess: true,//未结束进程
          })
          wx.showModal({
            title: '游戏结束，即将进入结算页面',
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                wx.redirectTo({
                  url: '../record/record?id=' + _this.data.scheduleId + '&teamId=' + _this.data.userInfo.teamId + '&type=1'
                })
              }
            }
          })
        } else if (_this.data.total >= 0) {
          minute = parseInt(_this.data.total / 60);
          second = parseInt(_this.data.total % 60);
          widthSli = (_this.data.total / 1800).toFixed(2) * 100;
        }
        _this.setData({
          total: _this.data.total - 1,
          minute: utils.formatNumber(minute),
          second: utils.formatNumber(second),
          widthSli: widthSli
        })
      }, 1000)
    })
    
  },
  //关闭所有计时器
  closeAllTimer() {
    clearInterval(this.data.headTimer);
    clearInterval(this.data.headTimer1);
  }
})