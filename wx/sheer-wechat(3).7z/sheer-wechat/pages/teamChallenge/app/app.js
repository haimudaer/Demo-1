var app = getApp();
var mtabW;
var timeOut = null;
var utils = require('../../../utils/util.js')
Page({
  data: {
    ipImg: app.ipImg,
    userInfo: {},
    height: app.globalData.windowHeight(),
    tabs: ['我的赛程', "历史赛程"],
    activeIndex: 0,
    slideOffset: 0,
    tabW: 0,
    util: utils,
    currentChallenge: [], //正在进行的赛程
    unOpenChallenge: [], //即将开始的赛程
    historyChallenge: [], //历史赛程

    current: 1,
    loadingAll:false, //数据是否加载完毕

    isLoader0: false,
    isLoader1: false,
  },
  //事件处理函数
  onLoad: function () {
    var thas = this;
    wx.getSystemInfo({
      success: function (res) {
        mtabW = res.windowWidth / 2;  //设置tab的宽度
        thas.setData({
          tabW: mtabW
        })
      }
    });
    thas.setData({
      userInfo: wx.getStorageSync('serverUser'),
    });
  },
  tabClick: function (e) {
    var that = this;
    var idIndex = e.currentTarget.id;
    var offsetW = e.currentTarget.offsetLeft;  //2种方法获取距离文档左边有多少距离
    clearTimeout(timeOut);
    timeOut = setTimeout(() => {
      this.setData({
        activeIndex: idIndex,
        slideOffset: offsetW
      });
    }, 100);
  },
  /* flag 0: 我的赛程,1:历史赛程*/
  bindChange: function (e) {    
    if (e.detail.current == 0) {
      this.getMyChallenge(); // 获取我的赛程
    }
    if (e.detail.current == 1) {
      this.setData({
        current:1,
        historyChallenge:[],
        loadingAll:false,
      })
      this.getHistoryChallenge(); //获取历史赛程
    }
    var current = e.detail.current;
    var offsetW = current * mtabW;    //2种方法获取距离文档左边有多少距离
    clearTimeout(timeOut);
    timeOut = setTimeout(() => {
      this.setData({
        activeIndex: current,
        slideOffset: offsetW
      });
    }, 100);

  },
  onShow: function () {
    this.getMyChallenge();// 获取我的赛程
  },
  /**下拉刷新 */
  onPullDownRefresh: function () {
    setTimeout(function () {
      wx.stopPullDownRefresh();
    }, 1000);
  },
  /**上拉加载 flag 0: 我的赛程,1:历史赛程*/
  onReachBottom: function (e) {
    if (!this.data.loadingAll){
        this.setData({
          current: this.data.current + 1,
        });
        this.getHistoryChallenge(); //获取历史赛程
    }
  },
  // 获取我的赛程
  getMyChallenge:function(){
    let _this = this;
    wx.request({
      url: app.ip + app.api.mySchedule,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          let body = res.data.body;
          if (body.currentScheduleList != null && body.currentScheduleList.length > 0){
            for (let i = 0; i < body.currentScheduleList.length; i++) {
              body.currentScheduleList[i]["startTime"] = _this.changeFormatDate(body.currentScheduleList[i]["startTime"]);
            }
          } 
          if (body.afterScheduleList != null && body.afterScheduleList.length > 0) {
            for (let i = 0; i < body.afterScheduleList.length; i++) {
              body.afterScheduleList[i]["startTime"] = _this.changeFormatDate(body.afterScheduleList[i]["startTime"]);
            }
          }
          _this.setData({
            isLoader0:true,
            currentChallenge: body.currentScheduleList ? body.currentScheduleList : [], //正在进行的赛程
            unOpenChallenge: body.afterScheduleList ? body.afterScheduleList : [], //即将开始的赛程
          })


          // 设置跑马灯
          if (_this.data.currentChallenge.length > 0 && _this.data.currentChallenge[0].firstTN.length > 6){
            _this.getWith(0);
          }
          if (_this.data.currentChallenge.length > 0 && _this.data.currentChallenge[0].secondTN.length > 6) {
            _this.getWith(1);
          }
        }
      },
      fail(error) {
        console.log(`获取我的赛程失败`, error);
      }
    })
  },
  // 获取历史赛程
  getHistoryChallenge: function () {
    let _this = this;
    wx.request({
      url: app.ip + app.api.historySchedule,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data:{
        current:_this.data.current,
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          let body = (res.data.body.records != null ? res.data.body.records : [] );
          if (body.length > 0) {
            for (let i = 0; i < body.length; i++) {

              var end = new Date().getTime(); //系统当前时间
              var start = new Date(body[i].startTime.replace(/-/g, "\/")).getTime(); //赛程开始时间

              // 当前时间 - 赛程开始时间 小于等于 33（33*60*1000 = 1980000 毫秒） 分钟 
              if (end - start <= 1980000) {
                body[i].result = true;
              } else {
                body[i].result = false;
              }


              body[i].startTime = _this.changeFormatDate(body[i].startTime);
              if (body[i].firstTeamScore != null){
                body[i].firstTeamScore = Math.floor(body[i].firstTeamScore*100)/100;
              }
              if (body[i].secondTeamScore != null){
                body[i].secondTeamScore = Math.floor(body[i].secondTeamScore * 100) / 100;
              }

            }
          }
          _this.setData({
            isLoader1: true,
            loadingAll: _this.data.current >= res.data.body.pages ? true : false,
            historyChallenge: _this.data.historyChallenge.concat(body), //今日赛程
          })
        } else if (res.data.code == -1){
          _this.setData({
            isLoader1: true,
            loadingAll: true ,
            historyChallenge:[], //今日赛程
          })
        }
      },
      fail(error) {
        console.log(`获取历史赛程失败`, error);
      }
    })
  },
  changeFormatDate:function(value){
    if (value){
      var date = utils.formatDate(value, 'M月D日 h:m');
      return date
    }else{
      return value
    }
  },
  //即将开始
  onStart(){
    wx.showToast({ title: "比赛即将开始", icon: 'none', duration: 1000 });
  },
  // 查看历史赛程
  history(e){
    let firstteamscore = e.currentTarget.dataset.firstteamscore; //第一队比赛分数
    let secondteamscore = e.currentTarget.dataset.secondteamscore; //第二队比赛分数
    let result = e.currentTarget.dataset.result; //result小于33分钟为 true 
    if (result == false && firstteamscore === null && secondteamscore === null){
      wx.showToast({ title: "未进行比赛", icon: 'none', duration: 1000 });
    } else if (result == true && firstteamscore === null && secondteamscore === null){
      wx.showToast({ title: "结果统计中", icon: 'none', duration: 1000 });
    }else{
      wx.navigateTo({
        url: '../record/record?id=' + e.currentTarget.dataset.id + '&teamId=' + this.data.userInfo.teamId + '&type=0'
      })
    }
  },
  util: function (obj,index) {
    var continueTime = (parseInt(obj.list / obj.container) + 1) * 2000;
    var setIntervalTime = 50 + continueTime;

    var animation = wx.createAnimation({
      duration: 200,  //动画时长
      timingFunction: "linear", //线性
      delay: 0  //0则不延迟
    });
    this.animation = animation;
    
    animation.translateX(obj.container).step({ duration: 50, timingFunction: 'step-start' }).translateX(-obj.list).step({ duration: continueTime });
      if(index == 0){
        this.setData({
          animationData0: animation.export()
        })
      }else{
        this.setData({
          animationData1: animation.export()
        })
      }
    setInterval(() => {
      animation.translateX(obj.container).step({ duration: 50, timingFunction: 'step-start' }).translateX(-obj.list).step({ duration: continueTime }    );
      if (index == 0) {
        this.setData({
          animationData0: animation.export()
        })
      } else {
        this.setData({
          animationData1: animation.export()
        })
      }
    }, setIntervalTime)
  },
  getWith(index) {
    var obj = new Object(); 
    var query = wx.createSelectorQuery();
    if (index == 0){
      query.select('.first-ranking').boundingClientRect();
      query.select('.first-ranking .text').boundingClientRect();
    } else {
      query.select('.second-ranking').boundingClientRect();
      query.select('.second-ranking .text').boundingClientRect();
    }
    //创建节点选择器
    
    query.exec((res) => {
      obj.container = res[0].width; // 框的height
      obj.list = res[1].width; // list的height
      this.util(obj,index);
    })
  }
})