const app = getApp()
var WxParse = require('../../wxParse/wxParse.js');

Page({

  data: {
    ipImg: app.ipImg,
    height: app.globalData.windowHeight(),
    item: [],
  },
  onLoad: function () {
    let thas = this;
    app.http(app.api.getText, { flag : 0}, function (res) {
      res.data.body.content = res.data.body.content.replace('<img', '<img style="max-width:100%;height:auto" ') //防止富文本图片过大
      thas.setData({
        item: res.data.body
      });
      WxParse.wxParse('content', 'html', thas.data.item.content, thas, 5);
    }, function () { }, true);
  },
  closeNotice: function () {
    wx.navigateBack({ changed: true });//返回上一页
  }
})