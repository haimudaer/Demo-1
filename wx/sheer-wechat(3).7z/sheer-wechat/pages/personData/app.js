import * as echarts from '../../ec-canvas/echarts';
import NumberAnimate from "../../utils/NumberAnimate";

const app = getApp();

function initChart(canvas, width, height) {
  const chart = echarts.init(canvas, null, {
    width: 300,
    height: 220
  });
  canvas.setChart(chart);
  console.log(wx.getStorageSync('radarData'));
  var color = "#CB2E2D";
  wx.getSystemInfo({
    success: function (res) {
      if (res.system.indexOf("iOS") != -1) {
        color = "#CB2E2D";
      }
    }
  })
  
  var option = {
    //backgroundColor: "#eee",
    color: ["#37A2DA", "#FF9F7F"],
    tooltip: {},
    textStyle: {
      fontWeight: 'normal',              //标题颜色  
      color: '#fff'
    },
    xAxis: {
      show: false
    },
    yAxis: {
      show: false
    },
    radar: {
      // shape: 'circle', //圆形
      indicator: [{
        name: '理论',
        max: 1
      },
      {
        name: '讲话',
        max: 1
      },
      {
        name: '党纪',
        max: 1
      },
      {
        name: '党规',
        max: 1
      },
      {
        name: '党章',
        max: 1
      },
      {
        name: '党史',
        max: 1
      }
      ]
    },
    series: [{
      tooltip: {
        trigger: 'item'
      },
      symbol: 'none', //去掉圆点
      itemStyle: {
        normal: {
          areaStyle: { type: 'default' }, 
          lineStyle: { width: 0 } //去掉边框
        } 
      },
      type: 'radar',
      color: color,
      data: [
        { value: wx.getStorageSync('radarData') }
      ]
    }]
  };

  chart.setOption(option);
  return chart;
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    ipImg: app.ipImg,
    height: app.globalData.windowHeight(),
    userInfo: {},
    countData: null,
    rank: null,
    ec: {
      onInit: initChart
    },
    teamRank:null,//团队排行
  },
  onShow:function(){
    const thas = this;
    //获取登录serverUser
    wx.getStorage({
      key: 'serverUser',
      success: function (res) {
        thas.setData({
          userInfo: res.data
        });
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const thas = this;
    //获取登录serverUser
    wx.getStorage({
      key: 'serverUser',
      success: function (res) {
        thas.setData({
          userInfo: res.data
        });
        thas.getTeamRan();//获取我所在战队的排名
      }
    })
    app.http(app.api.getRadarV2, {  }, function (res) {
      let item = res.data.body;
      let data = new Array(6);
      for (let i = 0; i < item.length; i++) {
        if (item[i].categoryId == 1) {
          data[0] = item[i].ratio;
        }
        if (item[i].categoryId == 6) {
          data[1] = item[i].ratio;
        }
        if (item[i].categoryId == 5) {
          data[2] = item[i].ratio;
        }
        if (item[i].categoryId == 4) {
          data[3] = item[i].ratio;
        }
        if (item[i].categoryId == 3) {
          data[4] = item[i].ratio;
        }
        if (item[i].categoryId == 2) {
          data[5] = item[i].ratio;
        }
      }

      wx.setStorageSync("radarData", data);
     
    }, function () { }, true);

    app.http(app.api.getRadarOther, {}, function (res) {
      res.data.body.winningProbability = res.data.body.winCount == 0 || res.data.body.count == 0 ? 0 : Math.floor(res.data.body.winCount / res.data.body.count * 100);
      thas.setData({
        countData: res.data.body
      })
      thas.numberAnimate(res.data.body.score);
    }, function () { }, true);

    app.http(app.api.getSelfRank, {}, function (res) {
      thas.setData({
        rank: res.data.body
      })
    }, function () { }, true);

    
  }, 
  // 获取我所在战队的排名
  getTeamRan() {
    let _this = this;
    wx.request({
      url: app.ip + app.api.teamWarRankTeam,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data: {
        teamId: _this.data.userInfo.teamId
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          res.data.body.score = parseInt(res.data.body.score);
          _this.setData({
            teamRank: res.data.body
          })
        }
      },
      fail(error) {
        console.log(`获取我的赛程失败`, error);
      }
    })
  },
  /**分享 */
  onShareAppMessage: function (res) {
    return {
      title: '来来来，快来挑战我',
      path: '/pages/index/app',
      success: function () {
        console.log("成功回调..");
      },
      fail: function () {
        console.log("失败回调..");
      }
    }
  },
  /**数字滚动动画 */
  numberAnimate: function (score) {
    let thas = this;
    let n1 = new NumberAnimate({
      from: score,//开始时的数字
      speed: 1000,// 总时间
      refreshTime: 100,//  刷新一次的时间
      decimals: 0,//小数点后的位数
      onUpdate: () => {//更新回调函数
        thas.data.countData.score = n1.tempValue
        thas.setData({
          countData: thas.data.countData
        });
      }
    });
  },
  //修改真实姓名
  editNickName:function(){
      wx.navigateTo({
            url: './../perfect/perfect?type=editNickName'
        })
  }
 
})