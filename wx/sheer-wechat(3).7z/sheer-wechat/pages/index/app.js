//获取应用实例
const app = getApp()
// var WxParse = require('../../wxParse/wxParse.js');
import NumberAnimate from "../../utils/NumberAnimate";

//媒体播放
const innerAudioContext = wx.createInnerAudioContext();

Page({
  data: {
    ipImg: app.ipImg,
    serverImg: app.serverImg,
    userInfo: null,
    height: app.globalData.windowHeight(),
    score: 0,
    countData: null,
    isAuthorization: false, //是否授权微信用户
    isLogin: false, //验证是否登录

    newsList:[],//新闻资讯列表
    switchInformation:'news',//切换新闻资讯 news  分支行动态branch
    /**设置逻辑 */
    animateClassName: "bounceIn",
    animateClassName2: "fadeIn",
    isShowSetting: false,
    noticeClassName: "",
    noticeText: "关",
    soundClassName: "",
    soundText: "关",
    isNoticeNum: 0,
    isSoundNum: 0,

    /**邀请码逻辑 */
    bindBtnClassName: "",
    code: "",
    isShowBind: app.globalData.isBind,
    isShowBindClassName: "",

    /**公告逻辑 */
    noticeClassName: "bounceInUp",
    isShowNotice: false,
    noticeItem: null,

    /**领取奖励 */
    receiveClassName: "zoomIn",
    isShowReceive: false,
    days: 0, //存放天数
    config: null,

    houseId: null, //房间ID
    isShowClassName: "",
    xing: 0,
    
  },
  onReady: function () {
    //innerAudioContext.src = "http://139.129.111.76:8108/sheer-api/images/background.mp3";
    innerAudioContext.onPlay(() => {
      console.log('开始播放')
    })
  },
  /**页面加载 */
  onLoad: function (e) {
    const thas = this;

    /*存储只读取一次新闻资讯  newslist :本地缓存新闻资讯*/
    let newslist;
    try {
      newslist = wx.getStorageSync('newslist');
    } catch (e) {
       console.log('获取新闻资讯失败');
    }
    if(newslist){
       try {
          wx.getStorage({
              key: 'newslist',
              success (res) {
                 thas.setData({
                    newslist: thas.splicingPath(JSON.parse(res.data))
                  });
              }
            })
        } catch (e) {console.log(e)}
    }else{
         // 获取新闻资讯
        wx.request({
          url: app.ip + app.api.getnewlist,
          // url:"http://192.168.1.111:8022/api/news/list",
          method: 'GET',
          header: {
            'content-type': 'application/json'
          },
          success(res) {
            if (res.data.code == 200 && res.data.status == true) {
              thas.setData({
                newslist: thas.splicingPath(res.data.body.records)
              });
              try {
                  wx.setStorageSync('newslist', JSON.stringify(res.data.body.records));
               } catch (e) { }
            }
          }
        })
    }

    wx.getSetting({
      success: res => {
        if (!res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: res => {
              thas.setData({
                userInfo: res.userInfo,
                isAuthorization: true
              })
            }
          })
        }
      }
    })

    thas.setData({
      houseId: e.houseId ? e.houseId : null //存放分享得来的房间ID
    });
    /**调用登录 */
    app.login().then((result) => {
      thas.setData({
        isShowBind: app.globalData.isBind,
        userInfo: result,
        isLogin: true
      });

    

      /**是否显示 */
      app.http(app.api.isStudyToday, {}, function (res) {
        thas.setData({
          isShowClassName: res.data.body == 0 ? "box-img" : ""
        });
      }, function () { }, true);

      /**在线人数 */
      app.http(app.api.getOnlineSize, {}, function (res) {
        thas.numberAnimate2(res.data.body);
      }, function () { }, true);

      /**假如是分享进入，跳转答题页面 */
      if (thas.data.houseId != undefined && thas.data.houseId != null) {
        wx.navigateTo({
          url: '../battle/app?houseId=' + e.houseId + '&type=100',
        })
      }

      /**获取设置 */
      thas.setData({
        isNoticeNum: result.isShowNotice,
        isShowNotice: result.isShowNotice == 1 ? true : false,
        isSoundNum: result.isSound
      });

      if (result.isShowNotice == 1) {
        if (new Date(wx.getStorageSync('isShowNotice').time).getTime() == new Date(new Date().format("yyyy-MM-dd")).getTime()) {
          thas.setData({
            isShowNotice: false
          });
        }
        else {
          thas.setData({
            isShowNotice: true
          });
        }
        
        wx.setStorage({
          key: "isShowNotice",
          data: {
            time: new Date().format("yyyy-MM-dd")
          }
        })
        
      }

      wx.setStorage({
        key: "isSound",
        data: result.isSound
      })

      if (wx.getStorageSync('isSound') == 1) {
        innerAudioContext.play();
      }

      /**调用初始化接口 */
      //thas.getInitData();
      /**获取排名   屏蔽 */
      // app.http(app.api.countData, { flag: 0, pageNO: 0, pageSize: 0 }, function (res) {
      //   thas.setData({
      //     countData: res.data.body
      //   });
      // }, function () { }, true);

      /**获取积分 */
      thas.getScore();

      /**获取公告 */
      app.http(app.api.getNotice, {}, function (res) {
        thas.setData({
          noticeItem: res.data.body
        });
        // WxParse.wxParse('noticeContent', 'html', res.data.body.content, thas, 5);
      }, function () { }, true);

      /**获取领取--是否显示领取 */
      app.http(app.api.checkSign, {}, function (res) {
        thas.setData({
          isShowReceive: !res.data.body,
        });
        if (!res.data.body) {
          /**获取签到天数 */
          app.http(app.api.getSignDays, {}, function (res) {
            thas.setData({
              days: res.data.body.sign,
              config: res.data.body.config,
            });
          }, function () { }, true);
        }

      }, function () { }, true);

      /**第一次获取雷达图 */
      if (wx.getStorageSync("isFirstRadar") == null || wx.getStorageSync("isFirstRadar") == "") {
        app.http(app.api.getRadarV2, {}, function (res) {
          let item = res.data.body;
          let data = new Array(6);
          for (let i = 0; i < item.length; i++) {
            if (item[i].categoryId == 1) {
              data[0] = item[i].ratio;
            }
            if (item[i].categoryId == 6) {
              data[1] = item[i].ratio;
            }
            if (item[i].categoryId == 5) {
              data[2] = item[i].ratio;
            }
            if (item[i].categoryId == 4) {
              data[3] = item[i].ratio;
            }
            if (item[i].categoryId == 3) {
              data[4] = item[i].ratio;
            }
            if (item[i].categoryId == 2) {
              data[5] = item[i].ratio;
            }
          }

          wx.setStorageSync("radarData", data);
          wx.setStorageSync("isFirstRadar", true);

        }, function () { }, true);
      }

      app.http(app.api.getCurrentLevel, {}, (res) => {
        thas.setData({
          xing: res.data.body.star
        });
      }, () => {}, true);

    }).catch((error) => {
      thas.setData({
        isShowBind: app.globalData.isBind,
      });
    });
  },
  onHide: function () {
    innerAudioContext.pause();
  },
  // switchInformation:'information',//切换新闻资讯 news  分支行动态branch
  switchBranch:function(e){
    const thas = this;
    wx.showLoading({ title: '加载中', mask: true });
    let type=e.currentTarget.dataset.url;
    thas.setData({switchInformation:type});
    //获取新闻资讯type=news   //获取分支行动态 type=branch
    wx.request({
      url: app.ip + app.api.getnewlist+`?type=${type}`,
      // url:"http://192.168.1.111:8022/api/news/list",
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          wx.hideLoading();
          thas.setData({
            newslist:thas.splicingPath(res.data.body.records)
          })
        }
      },
      fail(error){
         wx.hideLoading();
        console.log(`切换新闻资讯失败`,error);
      }
    })
  
  },
  /**显示 */
  onShow: function () {
    const thas = this;
    if (thas.data.isLogin) {
      if (wx.getStorageSync('isSound') == 1) {
        innerAudioContext.play();
      }
      /**获取积分 */
      thas.getScore();

      /**是否显示 */
      app.http(app.api.isStudyToday, {}, function (res) {
        thas.setData({
          isShowClassName: res.data.body == 0 ? "box-img" : ""
        });
      }, function () { }, true);

      /**在线人数 */
      app.http(app.api.getOnlineSize, {}, function (res) {
        thas.numberAnimate2(res.data.body);
      }, function () { }, true);

      /**获取服务器用户 */
      app.http(app.api.getInfo, {}, function (res) {
        wx.setStorage({
          key: "userInfo",
          data: res.data.body
        })
        thas.setData({
          userInfo: res.data.body
        })
      }, function () { }, true);

      /**获取排名   屏蔽*/
      // app.http(app.api.countData, { flag: 0, pageNO: 0, pageSize: 0 }, function (res) {
      //   thas.setData({
      //     countData: res.data.body
      //   });
      // }, function () { }, true);

      app.http(app.api.getCurrentLevel, {}, (res) => {
        thas.setData({
          xing: res.data.body.star
        });
      }, () => { }, true);
      
    }
    
  },
  /**数组筛选   拼接完整图片地址 */
  splicingPath:function(arr){
      arr.map(item=>{
        if(item&&item.cover){
           if(item.cover.indexOf('pbc/news')!=-1&&item.cover.indexOf('https')==-1&&item.cover.indexOf('http')==-1){
             item.cover=app.serverImg+item.cover;
            }
             if(item.cover.indexOf('aliyuncs')!=-1&&item.cover.indexOf('https')==-1&&item.cover.indexOf('http')==-1){
              item.cover='https://'+item.cover;
            }
            console.log(item.cover,'````````````````````````````')
        }
        return item
      })
      return arr;
  },
  /**获取用户信息 */
  getUserInfo: function (e) {
    console.log(e.detail.userInfo);
    if (e.detail.userInfo != undefined) {
      this.setData({
        userInfo: e.detail.userInfo,
        isAuthorization: true,
      })
      this.submitRegister();
    }
  },
  /**监听输入邀请码 */
  watchInput: function (event) {
    this.setData({
      code: event.detail.value,
      bindBtnClassName: event.detail.value == "" ? "" : "active"
    })
  },
  /**提交邀请码 */
  submitRegister: function () {
    let thas = this;
    if (app.globalData.empty(thas.data.code)) {
      wx.showToast({ title: "请输入邀请码",  icon: 'none',  duration: 2000 });
      return false;
    }
    else if (app.globalData.isEmoji.test(thas.data.code)) {
      wx.showToast({ title: "不支持表情", icon: 'none', duration: 2000 });
      return false;
    }
    else {
      /**提交绑定   修改登录流程   完善信息*/
        let codes=thas.data.code;
        try {
            codes= (codes.replace(/\s*/g,"")).toUpperCase();
        } catch (error) {
            codes=thas.data.code;
            console.log(error)
        }
        wx.request({
          url: app.ip + app.api.getOrganization+`?code=${codes}`,
          // url:"http://192.168.1.111:8022/api/news/list",
          method: 'GET',
          header: {
              'content-type': 'application/json'
          },
          success(res) {
            console.log(res,'``````res')
              if ((res.data.code == 200||res.data.code == 2043) && res.data.status == true) {
                /**存储绑定用户信息key:bindUsers  object   openId code avatar nickName  organizationId cityId  */
                wx.setStorageSync("bindUsers", {
                  ...res.data.body, 
                  openId: wx.getStorageSync('openId'),
                  code: codes,
                  avatar: thas.data.userInfo.avatarUrl,
                  nickName: thas.data.userInfo.nickName});
                /**跳转完善用户信息页面 */
                wx.navigateTo({
                    url: './../perfect/perfect'
                })

              }else{
                  wx.showToast({ title: "邀请码无效", icon: 'none', duration: 2000 });
              }
          },
          
        })
      // app.http(app.api.bindOpenId, {
      //   openId: wx.getStorageSync('openId'),
      //   code: thas.data.code,
      //   avatar: thas.data.userInfo.avatarUrl,
      //   nickName: thas.data.userInfo.nickName,
      // }, function (result) {
      //   console.log(result,'eqeqe````````');
        // thas.setData({
        //   isShowBindClassName: "bounceOutUp",
        //   userInfo: result.data.body,
        //   isLogin: true,
        //   isNoticeNum: result.data.body.isShowNotice,
        //   isShowNotice: result.data.body.isShowNotice == 1 ? true : false,
        //   isSoundNum: result.data.body.isSound
        // });

        // wx.setStorage({
        //   key: "isShowNotice",
        //   data: {
        //     time: new Date().format("yyyy-MM-dd")
        //   }
        // })

        // wx.setStorage({
        //   key: "isSound",
        //   data: result.data.body.isSound
        // })
        // if (wx.getStorageSync('isSound') == 1) {
        //   innerAudioContext.play();
        // }

        // app.globalData.isBind = false;
        // app.token = result.data.body.token;

        // /**调用初始化接口 */
        // thas.getInitData();

        // setTimeout(() => {
        //   thas.setData({
        //     isShowBind: false,
        //   });
        //   //验证好友未授权，然后授权继续跳转
        //   if (thas.data.houseId != undefined) {
        //     wx.navigateTo({
        //       url: '../battle/app?houseId=' + e.houseId + '&type=100',
        //     })
        //   }
        // }, 1000);

        // wx.setStorage({
        //   key: "serverUser",
        //   data: result.data.body
        // })
      // }, function () { }, true);
    }

  },
  /**获取积分 */
  getScore: function () {
    let thas = this;
    app.http(app.api.getScore, {}, function (res) {
      thas.numberAnimate(res.data.body);
    }, function () { }, true);
  },
  /**初始化请求接口 */
  getInitData: function () {
    let thas = this;
    /**获取排名  屏蔽 */
    // app.http(app.api.countData, { flag: 0, pageNO: 0, pageSize: 0 }, function (res) {
    //   thas.setData({
    //     countData: res.data.body
    //   });
    // }, function () { }, true);

    /**获取积分 */
    thas.getScore();

    /**获取公告 */
    app.http(app.api.getNotice, {}, function (res) {
      thas.setData({
        noticeItem: res.data.body
      });
    }, function () { }, true);

    /**在线人数 */
    app.http(app.api.getOnlineSize, {}, function (res) {
      thas.numberAnimate2(res.data.body);
    }, function () { }, true);

    /**获取领取--是否显示领取 */
    app.http(app.api.checkSign, {}, function (res) {
      thas.setData({
        isShowReceive: !res.data.body,
      });
      if (!res.data.body) {
        /**获取签到天数 */
        app.http(app.api.getSignDays, {}, function (res) {
          thas.setData({
            days: res.data.body.sign,
            config: res.data.body.config,
          });
        }, function () { }, true);
      }

    }, function () { }, true);

    /**是否显示 */
    app.http(app.api.isStudyToday, {}, function (res) {
      thas.setData({
        isShowClassName: res.data.body == 0 ? "box-img" : ""
      });
    }, function () { }, true);

  },
  /**好友对战 */
  friendsPK: function () {
     wx.showToast({
        title: "暂未开放",
        icon: 'none',
        duration: 1000
      })
      return false;
    // //type 固定100 表示 好友对战
    // if (this.data.userInfo == null) {
    //   wx.showToast({
    //     title: "授权失败",
    //     icon: 'none',
    //     duration: 1000
    //   })
    // }
    // else {
    //   wx.navigateTo({
    //     url: "../battle/app?type=100"
    //   })
    // }
  },
  /**关闭领取奖励弹窗 */
  closeRward:function () {
      this.setData({isShowReceive:false})
  },
  /**机器人对战 */
  robotPK: function () {
    //type 固定200 表示 机器人对战
    if (this.data.userInfo == null) {
      wx.showToast({
        title: "授权失败",
        icon: 'none',
        duration: 1000
      })
    }
    else {
      wx.navigateTo({
        url: "../battle/app?type=200"
      })
    }
  },
  /**跳转对应的页面 */
  jump: function (e) {
    if(e.currentTarget.dataset.url==='Developing'){
       wx.showToast({
        title: "暂未开发",
        icon: 'none',
        duration: 1000
      })
      return false;
    }

    if (this.data.userInfo == null) {
      wx.showToast({
        title: "授权失败",
        icon: 'none',
        duration: 1000
      })
      return false;
    }

    if (e.currentTarget.dataset.url === 'aualifying') {
      wx.request({
        url: app.ip + app.api.individual,
        method: 'GET',
        header: {
          'content-type': 'application/json',
          'token': app.token,
        },
        data: {},
        success(res) {
          if (res.data.code == 200 && res.data.status == true) {
            if (!res.data.body.enabled){
              wx.showToast({
                title: res.data.body.msg,
                icon: 'none',
                duration: 1000
              })
            }else{
              wx.navigateTo({
                url: '../' + e.currentTarget.dataset.url + "/app"
              })
            }
          }
        },
        fail(error) { }
      })
    }else{
      wx.navigateTo({
        url: '../' + e.currentTarget.dataset.url + "/app"
      })
    }
  },
  /**设置 */
  openSetting: function () {
    let thas = this;
    this.setData({
      animateClassName: "bounceIn",
      animateClassName2: "fadeIn",
      isShowSetting: true,
    });
    
    setTimeout(function () {
      thas.setData({
        noticeClassName: thas.data.isNoticeNum == 1 ? "open" : "",
        noticeText: thas.data.isNoticeNum == 1 ? "开" : "关",
        soundClassName: thas.data.isSoundNum == 1 ? "open" : "",
        soundText: thas.data.isSoundNum == 1 ? "开" : "关",
      });
    }, 500);
  },
  /**关闭设置 */
  closeSetting: function() {
    let thas = this;
    this.setData({
      animateClassName: "bounceOut",
      animateClassName2: "fadeOut"
    });

    setTimeout(function () {
      thas.setData({
        isShowSetting: false,
        noticeClassName: "",
        noticeText: "关",
        soundClassName: "",
        soundText: "关",
      });
    }, 500);
  },
  /**关闭公告页面 */
  closeNotice: function () {
    let thas = this;
    thas.setData({
      noticeClassName: "zoomOut"
    });
    setTimeout(() => {
      thas.setData({
        isShowNotice: false,
      });
    }, 500);
  },
  /**领取奖励 */
  receiveReward: function () {
    let thas = this;
    app.http(app.api.sign, { days : thas.data.days + 1 }, function (res) {
      thas.setData({
        receiveClassName: "zoomOut"
      });
      /**获取积分 */
      thas.getScore();

      setTimeout(() => {
        thas.setData({
          isShowReceive: false,
        });
      }, 500);
      wx.showToast({
        title: '领取成功',
        duration: 2000,
        icon: "none"
      })
    }, function () { }, true);
  },
  /**开关公告 */
  openNotice: function () {
    this.setSetting(0);
  },
  /**开关音效 */
  openSound: function () {
    this.setSetting(1);
  },
  /**设置 */
  setSetting: function (type) {
    let thas = this;
    let data = {}
    if (type == 0) {
      data = { isShowNotice: thas.data.isNoticeNum == 1 ? 0 : 1 }
    }
    else {
      data = { isSound: thas.data.isSoundNum == 1 ? 0 : 1 }
    }
    app.http(app.api.setData, data, function (res) {
      if (type == 0) {
        thas.setData({
          isNoticeNum: thas.data.isNoticeNum == 1 ? 0 : 1,
        });
        thas.setData({
          noticeClassName: thas.data.isNoticeNum == 1 ? "open" : "",
          noticeText: thas.data.isNoticeNum == 1 ? "开" : "关",
        });
      }
      else {
        thas.setData({
          isSoundNum: thas.data.isSoundNum == 1 ? 0 : 1,
        });
        thas.setData({
          soundClassName: thas.data.isSoundNum == 1 ? "open" : "",
          soundText: thas.data.isSoundNum == 1 ? "开" : "关",
        });
        wx.setStorage({
          key: "isSound",
          data: thas.data.isSoundNum
        })
        if (thas.data.isSoundNum == 1) {
          innerAudioContext.play();
        }
        else {
          innerAudioContext.pause();
        }
      }
    }, function () { }, true);
  },
  findNotice: function () {
    this.closeSetting();
    this.setData({
      isShowNotice: true
    });
  },
  /**数字滚动动画 */
  numberAnimate: function (score) {
    let thas = this;
    let n1 = new NumberAnimate({
      from: score,//开始时的数字
      speed: 1000,// 总时间
      refreshTime: 100,//  刷新一次的时间
      decimals: 0,//小数点后的位数
      onUpdate: () => {//更新回调函数
        thas.setData({
          score: n1.tempValue
        });
      }
    });
  },
  /**数字滚动动画 */
  numberAnimate2: function (score) {
    let thas = this;
    let n1 = new NumberAnimate({
      from: score,//开始时的数字
      speed: 1000,// 总时间
      refreshTime: 100,//  刷新一次的时间
      decimals: 0,//小数点后的位数
      onUpdate: () => {//更新回调函数
        thas.setData({
          onlineSize: n1.tempValue
        });
      }
    });
  },

})
