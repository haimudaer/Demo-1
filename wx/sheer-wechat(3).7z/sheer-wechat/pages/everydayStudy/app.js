const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    ipImg: app.ipImg,
    height: app.globalData.windowHeight(),
    fadeInDown: "zoomInLeft",
    fadeInUp: "zoomInRight",
    index: 0,
    subjectList: [],
    item: {},
    isEnd: false,
    isClickReceive: false,
    isShowClassName: "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let thas = this;

    /**获取每日一学题 */
    app.http(app.api.getStudy, {}, function (res) {
      for (let i = 0; i < res.data.body.length; i++) {
        let item = res.data.body[i];
        item.content = item.content.replace('<img', '<img style="max-width:100%;height:auto" ') //防止富文本图片过大
      }
      thas.setData({
        subjectList: res.data.body,
        item: res.data.body[0],
        isEnd: res.data.body.length == 1 ? true : false,
      });
      WxParse.wxParse('content', 'html', thas.data.subjectList[0].content, thas, 5);
      
    }, function () { }, true);


    app.http(app.api.isStudyToday, {}, function (res) {
      thas.setData({
        isShowClassName: res.data.body == 0 ? "box-shadow" : ""
      });
    }, function () { }, true);
    
  },
  /**上一题 */
  lastItem: function () {
    let thas = this;
    if (thas.data.subjectList.length > 1) {
      thas.setData({
        index: thas.data.index - 1,
        isEnd: false,
      });
      if (thas.data.index < 0) {
        thas.setData({
          index: 0
        });
      }
      else {
        thas.setData({
          fadeInDown: "zoomOutLeft",
          fadeInUp: "zoomOutRight",
        });
        setTimeout(() => {
          thas.setData({
            fadeInDown: "zoomInLeft",
            fadeInUp: "zoomInRight",
          });
        }, 500);
      }
      setTimeout(() => {
        thas.getData();
      }, 500);
    }
  },
  /**下一题 */
  nextItem: function () {
    let thas = this;
    if (thas.data.subjectList.length > 1) {
      thas.setData({
        index: thas.data.index + 1,
        fadeInDown: "zoomOutLeft",
        fadeInUp: "zoomOutRight",
      });
      setTimeout(() => {
        thas.setData({
          fadeInDown: "zoomInLeft",
          fadeInUp: "zoomInRight",
        });
      }, 500);
      if (thas.data.subjectList.length - 1 == thas.data.index) {
        thas.setData({
          isEnd: true,
          index: thas.data.subjectList.length - 1
        });
      }
      setTimeout(() => {
        thas.getData();
      }, 500);
    }
  },
  /**筛选题 */
  getData: function () {
    let thas = this;
    thas.setData({
      item: thas.data.subjectList[thas.data.index]
    });
    WxParse.wxParse('content', 'html', thas.data.subjectList[thas.data.index].content, thas, 5);
  },
  /**领取学分 */
  receive: function () {
    let thas = this;
    if (thas.data.isClickReceive) {
      return false;
    }
    thas.setData({
      isClickReceive: true,
    });
    app.http(app.api.studyFinish, {}, function (res) {
      wx.showToast({
        title: res.data.msg,
        duration: 2000,
        mask: true,
        success: function () {
          setTimeout(function () {
            wx.navigateBack({ changed: true });//返回上一页
          }, 2000)
        }
      })
    }, function () { }, true);
    
  }
 
})