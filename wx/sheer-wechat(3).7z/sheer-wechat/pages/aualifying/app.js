const app = getApp()
let timeOut = null, timeOut1 = null,repeatTime=null;
Page({
  data: {
    ipImg: app.ipImg,
    userInfo: {},
    height: app.globalData.windowHeight(),
    item: {},
    score: 0,
    types: [],
    scrollTop: 0,
    isShow: false,
    countData:null,
    repeatStatus:true,//避免重复点击
  },
  /**页面加载 */
  onLoad: function () {
    let thas = this;
    //获取登录serverUser
    thas.setData({
      userInfo: wx.getStorageSync('serverUser')
    });
  },
  /**页面显示 */
  onShow: function () {
    let thas = this;
    wx.showLoading({ title: '加载中', mask: true })
    app.http(app.api.getCurrentLevel, {}, (res) => {
      console.log(res);
      thas.setData({
        item: res.data.body
      });

      timeOut = setTimeout(() => {
        thas.setData({
          isShow: true
        });
        clearTimeout(timeOut);
      }, 1000);

      // timeOut1 = setTimeout(() => {
      //   let level = thas.data.item.maxLevel;
      //   /**暂时禁止向下滑动 */
      //   return;
      //   if (level == 0 || level == 1 || level == 2 || level == 3 || level == 4 || level == 5) {
      //     thas.setData({
      //       scrollTop: thas.data.height
      //     });
      //   }
      //   else if (level == 6) {
      //     thas.setData({
      //       scrollTop: 300
      //     });
      //   }
      //   else if (level == 7) {
      //     thas.setData({
      //       scrollTop: 200
      //     });
      //   }
      //   else if (level == 8) {
      //     thas.setData({
      //       scrollTop: 100
      //     });
      //   }
      //   else if (level == 9) {
      //     thas.setData({
      //       scrollTop: 80
      //     });
      //   }
      //   else {
      //     thas.setData({
      //       scrollTop: 0
      //     });
      //   }

      //   clearTimeout(timeOut1);
      // }, 2000);

    }, () => {
      wx.hideLoading();
    }, true);

     /**调用初始化接口 */
      //thas.getInitData();
      /**获取排名 */
      app.http(app.api.countData, { flag: 0, pageNO: 0, pageSize: 0 }, function (res) {
        thas.setData({
          countData: res.data.body
        });
      }, function () { }, true);


    /**获取道具 */
    app.http(app.api.getSelfProp, {}, function (res) {
      thas.setData({
        types: res.data.body
      });
    }, function () { }, true);

    app.http(app.api.getScore, {}, function (res) {
      thas.setData({
        score: res.data.body
      });
    }, function () { }, true);

    /**获取服务器用户 */
    app.http(app.api.getInfo, {}, function (res) {
      wx.setStorage({
        key: "serverUser",
        data: res.data.body
      })
      thas.setData({
        userInfo: res.data.body
      })
    }, function () { }, true);

    /**在线人数 */
    app.http(app.api.isFinishAnswer, {}, function (res) {
      if (res.data.body) {
        wx.showModal({
          title: '恭喜您顺利通关，期待我们在下一期PK赛中再见！您也可以继续在各关卡与他人对战！',
          showCancel: false,
          success: function (res) {

          }
        })
      }
    }, function () { }, true);
    
  },
  /**选择关卡 */
  checkpoint: function (e) {
    let thas = this;
    if(!thas.data.repeatStatus){
      return false//减少频繁点击
    }
    thas.setData({
      repeatStatus: false
    });
    repeatTime=setTimeout(() => {
      thas.setData({
        repeatStatus: true
      });
    }, 1000);//1s点击一次
    let star = thas.countStar();
    app.http(app.api.isPlay, {}, function (res) {
      if (res.data.body) {
        if (e.currentTarget.dataset.type <= thas.data.item.maxLevel) {
          wx.navigateTo({
            url: '../battle/app?type=' + e.currentTarget.dataset.type,
          })
        }
        else if (e.currentTarget.dataset.type <= (thas.data.item.maxLevel + 1) && thas.data.item.star == star) {
          wx.navigateTo({
            url: '../battle/app?type=' + e.currentTarget.dataset.type,
          })
        }
        else if(e.currentTarget.dataset.type>20&&thas.data.item.maxLevel>=20&&thas.data.item.star>=110){//巅峰对决
            wx.navigateTo({
              url: '../battle/app?type=' + e.currentTarget.dataset.type,
            })
        }
        else {
          wx.showToast({
            title: '请按照顺序通过关卡',
            icon: "none",
            duration: 2000
          })
        }
      }
      else {
        wx.showToast({
          title: '今日场次已满，请明日继续',
          icon: "none",
          duration: 2000
        })
      }
    }, function () { }, true);

    
  },
  /**计算关卡星星 */
  countStar: function () {
    let level = this.data.item.maxLevel;
    switch(level) {
      case 0: return 0; break;
      case 1: return 1; break;
      case 2: return 2; break;
      case 3: return 4; break;
      case 4: return 6; break;
      case 5: return 9; break;
      case 6: return 12; break;
      case 7: return 16; break;
      case 8: return 20; break;
      case 9: return 25; break;
      case 10: return 30; break;
      case 11: return 36; break;
      case 12: return 42; break;
      case 13: return 49; break;
      case 14: return 56; break;
      case 15: return 64; break;
      case 16: return 72; break;
      case 17: return 81; break;
      case 18: return 90; break;
      case 19: return 100; break;
      case 20: return 110; break;
    }
    
  }
})
