 const app = getApp();
Page({

  /** 页面的初始数据 */
  data: {
    ipImg: app.ipImg,
    animateClassName1: "fadeIn",
    animateClassName2: "bounceIn",
    isShowModal: false,
    types: [],
   images: [{
      imgPath: "study-icon-edit-2.png",
      hints:  "使用星星卡可直接获得一颗关卡五角星",
          },
        {
          imgPath:  "study-icon-edit-1.png",
          hints:   "使用倍增卡可在接下来1场比赛中获得的经验值翻倍",
        },
        {
          imgPath:  "study-icon-edit-3.png",
          hints:  "排除卡可直接帮您去掉一个错误答案，降低答题难度",
        },
        {
          imgPath: "study-icon-edit-4.png",
          hints:   "创可贴可随机覆盖对手一个答案项，要是刚好覆盖...",
        },
        {
          imgPath:  "study-icon-edit-5.png",
          hints:   "秒选卡是系统直接帮您选择正确答案，一秒即可答对",
        }
    ],
    titles: [
       "使用星星卡可直接获得一颗关卡五角星",
      "使用倍增卡可在接下来1场比赛中获得的经验值翻倍",
      "排除卡可直接帮您去掉一个错误答案，降低答题难度",
      "创可贴可随机覆盖对手一个答案项，要是刚好覆盖到正确答案，那么对手将无正确答案可选",
      "秒选卡是系统直接帮您选择正确答案，一秒即可答对",
    ],
    item: {},
    title: "",
    thisImg: "",
    isClick: true,

  },

  /** 生命周期函数--监听页面加载 */
  onLoad: function (options) {
    let thas = this;
    /**获取道具 */
    app.http(app.api.getSelfProp, {}, function (res) {
      thas.setData({
        types: res.data.body
      });
    }, function () { }, true);
  },
  /**使用 */
  use: function () {
    let thas = this;
    if (!thas.data.isClick) {
      return false;
    }
    else {
      thas.setData({
        isClick: false
      });
      if (thas.data.item.propId == 0 || thas.data.item.propId == 1) {
        app.http(app.api.useProp, { propId: thas.data.item.propId }, function (res) {
          if (res.data.code == 200) {
            for (let j = 0; j < thas.data.types.length; j++) {
              if (thas.data.types[j].propId == thas.data.item.propId) {
                thas.data.types[j].num = thas.data.types[j].num - 1;
              }
            }
            thas.setData({
              types: thas.data.types
            });
            wx.showToast({
              title: '使用成功',
              duration: 1000,
              mask: true,
              success: function () {
                setTimeout(() => {
                  thas.hideModal();
                  thas.setData({
                    isClick: true
                  });
                }, 500);
              },
            })
          }
          else {
            wx.showToast({
              title: res.data.msg,
              icon: "none",
              duration: 1000,
            })
            thas.setData({
              isClick: true
            });
          }
          
        }, function () { }, false);
      }
      else {
        thas.setData({
          isClick: true
        });
        wx.showToast({
          title: '背包不可使用此道具',
          icon: "none",
          duration: 1000
        })
      }
    }
    
  },
  /**显示弹窗 */
  showModal: function (e) {
    let thas = this;
    console.log(thas.data.types,e.currentTarget.dataset.type, thas.data.types[e.currentTarget.dataset.type]);
    this.setData({
      item: thas.data.types[e.currentTarget.dataset.type],
      thisImg: thas.data.images[e.currentTarget.dataset.type].imgPath,
      title: thas.data.titles[e.currentTarget.dataset.type],
      animateClassName1: "fadeIn",
      animateClassName2: "bounceIn",
      isShowModal: true,
    });
  },
  /**隐藏弹窗 */
  hideModal: function () {
    let thas = this;
    this.setData({
      animateClassName1: "fadeOut",
      animateClassName2: "bounceOut",
    });
    setTimeout(function () {
      thas.setData({
        isShowModal: false,
      });
    }, 500);
  },
  /**没有卡提示 */
  notNum: function (e) {
    wx.showToast({
      title: '暂无' + this.data.types[e.currentTarget.dataset.type].propName,
      duration: 1000,
      icon: "none"
    })
  },


})