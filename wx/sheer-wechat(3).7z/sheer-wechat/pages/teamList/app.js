var app = getApp();
var mtabW;
var timeOut = null;
Page({
  data: {
    ipImg: app.ipImg,
    userInfo: {},
    height: app.globalData.windowHeight(),
    tabs: [ '团战排行',"机构排行"],
    activeIndex: 0,
    slideOffset: 0,
    tabW: 0,
    personData: null,
    teamList: [], //团战排行列表
    mechanismList: [],//机构列表
    pageSize: 10,
    pageNo1: 1,
    pageNo2: 1,
    countData: null,
    isLoader1:false,
    isLoader2:false,
    rank1: 0,
    rank2: 0,
    cityName: "",
  },
  //事件处理函数
  onLoad: function () {
    var _this = this;
    wx.getSystemInfo({
      success: function (res) {
        mtabW = res.windowWidth / 2;  //设置tab的宽度
        _this.setData({
          tabW: mtabW
        })
      }
    });

    _this.setData({
      userInfo: wx.getStorageSync('serverUser')
    });

    _this.getTeamRankList();//获取团战排行榜
    _this.getTeamRan();//获取我所在战队的排名
  },
  tabClick: function (e) {
    var that = this;
    var idIndex = e.currentTarget.id;
    var offsetW = e.currentTarget.offsetLeft;  //2种方法获取距离文档左边有多少距离
    clearTimeout(timeOut);
    timeOut = setTimeout(() => {
      this.setData({
        activeIndex: idIndex,
        slideOffset: offsetW
      });
    }, 100);
  },
  bindChange: function (e) {
    if (e.detail.current == 0 && !this.data.isShow1) {
      this.setData({
        pageNo1: 1,
        teamList: [],
      })
      this.getTeamRankList();//获取团战排行榜
    }
    if (e.detail.current == 1 && !this.data.isShow2) {
      this.setData({
        pageNo2: 1,
        mechanismList: [],
      })
      this.getOrganization();//获取机构排行榜
    }
    var current = e.detail.current;
    var offsetW = current * mtabW;    //2种方法获取距离文档左边有多少距离
    clearTimeout(timeOut);
    timeOut = setTimeout(() => {
      this.setData({
        activeIndex: current,
        slideOffset: offsetW
      });
    }, 100);

  },
  /**分享 */
  onShareAppMessage: function (res) {
    return {
      title: '来来来，快来挑战我',
      path: '/pages/index/app',
    }
  },
  onShow: function () {

  },
  /**下拉刷新 */
  onPullDownRefresh: function () {
    setTimeout(function () {
      wx.stopPullDownRefresh();
    }, 1000);
  },
  onReachBottom: function (e) {
    console.log(e.currentTarget.dataset.type)
    if (e.currentTarget.dataset.type == 0) {
      this.setData({
        pageNo1: this.data.pageNo1 + 1
      });
      if (this.data.pageNo1 <= 20) {
        this.getTeamRankList();//获取团战排行榜
      }
    }

    if (e.currentTarget.dataset.type == 1) {
      this.setData({
        pageNo2: this.data.pageNo2 + 1
      });
      if (this.data.pageNo2 <= 20) {
        this.getOrganization();//获取机构排行榜
      }
    }
  },
  // 获取我所在战队的排名
  getTeamRan() {
    let _this = this;
    wx.request({
      url: app.ip + app.api.teamWarRankTeam,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data: {
        teamId: _this.data.userInfo.teamId
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          _this.setData({
            rank1: res.data.body.rank
          })
        }
      },
      fail(error) {
        console.log(`获取我的赛程失败`, error);
      }
    })
  },
  // 获取团战排行榜
  getTeamRankList(){
    let _this = this;
    wx.request({
      url: app.ip + app.api.teamWarRank,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'token': app.token,
      },
      data: {
        pageSize: _this.data.pageSize,
        pageNO: _this.data.pageNo1
      },
      success(res) {
        if (res.data.code == 200 && res.data.status == true) {
          let body = res.data.body;
          if(body.length > 0){
            for (var i = 0; i < body.length; i++){
              body[i].score = parseInt(body[i].score);
            }
            _this.setData({
              isLoader1: true,
              teamList: _this.data.teamList.length == 0 ? body : _this.data.teamList.concat(body), //正在进行的赛程
            })
          }else{
            _this.setData({isLoader1:true})
            _this.data.pageNo1--;
          }
        }
      },
      fail(error) {
        console.log(`获取我团战排行榜失败`, error);
      }
    })
  },
  // 获取机构排行榜
  getOrganization:function(){
    let _this = this;
    app.http(app.api.countData, {
      flag: 7,
      pageSize: _this.data.pageSize,
      pageNO: _this.data.pageNo2
    }, function (res) {
      let dataList = res.data.body.users;
      _this.setData({
        isLoader2: true,
        rank2: res.data.body.self.rank
      });
      if (dataList.length > 0) {
        _this.setData({
          mechanismList: _this.data.mechanismList.length == 0 ? dataList : _this.data.mechanismList.concat(dataList)
        });
      }
      else {
        _this.data.pageNo2--;
      }

    }, function () { }, true);
  },
})