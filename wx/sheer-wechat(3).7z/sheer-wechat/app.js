//app.js
App({
  onLaunch: function () {
    try {
      wx.removeStorageSync("newslist");
      wx.removeStorageSync("generatePbcId");
      // 获取小程序更新机制兼容
      // if (wx.canIUse("getUpdateManager")) {
      //   const updateManager = wx.getUpdateManager();
      //   updateManager.onCheckForUpdate(function(res) {
      //     // 请求完新版本信息的回调
      //     if (res.hasUpdate) {
      //       updateManager.onUpdateReady(function() {
      //         wx.showModal({
      //           title: "更新提示",
      //           content: "新版本已经准备好，是否重启应用？",
      //           success: function(res) {
      //             if (res.confirm) {
      //               // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
      //               updateManager.applyUpdate();
      //             }
      //           }
      //         });
      //       });
      //       updateManager.onUpdateFailed(function() {
      //         // 新的版本下载失败
      //         wx.showModal({
      //           title: "已经有新版本了哟~",
      //           content:
      //             "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
      //         });
      //       });
      //     }
      //   });
      // } else {
      //   // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
      //   wx.showModal({
      //     title: "提示",
      //     content:
      //       "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
      //   });
      // }
    } catch (e) {
      console.log('更新失败', e)
      // Do something when catch error
    }
  },
  /**
   * 公共方法
   */
  globalData: {
    /**存放用户信息 */
    userInfo: null,
    isBind: false,
    /**存放登录人信息 */
    serverUser: null,
    list: [],
    /**获取屏幕高度 */

    windowHeight: function () {
      let height = 0;
      wx.getSystemInfo({
        success: function (res) {
          height = res.windowHeight;
        }
      });
      return height;
    },
    /**emoji 表情正则**/
    isEmoji: /\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g,
    /**验证空**/
    empty: function (value) {
      return (
        value.trim() == null ||
        value.trim() == "" ||
        typeof value.trim() == "undefined"
      );
    },
  },
  // ip: "http://192.168.1.111:8022/api/",
  // ipImg: "http://192.168.1.111:8022/sheer-api/images/",
  // websocketIp: "http://192.168.1.111:8022/sheer-api/websocket",

  // /*1111服务器 */
  // ip: "http://192.168.1.111:8022/api/",
  // // ipImg: "http://192.168.1.111:8022/sheer-api/",
  //  ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // serverImg: "http://192.168.1.111:8080/",
  // websocketIp: "ws://192.168.1.111:8022/api//websocket",

  /**汪老师  */
  // ip: "http://192.168.1.34:8080/sheer/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // serverImg: "http://192.168.1.34:8080/sheer/",
  // websocketIp: "ws://192.168.1.34:8080/sheer/websocket",

  /*204服务器 */
  // ip: "http://192.168.1.40:8081/sheer-api/",
  // // ipImg: "http://192.168.1.40/sheer-api/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // websocketIp: "ws://192.168.1.40:8081/sheer-api/websocket",

  /**本地环境二 */
  // ip: "http://192.168.1.14:8088/sheer-api/",
  // // ipImg: "http://192.168.1.40:8081/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // serverImg: "http://192.168.1.14:8088/sheer-api/",
  // websocketIp: "ws://192.168.1.14:8088/sheer-api/websocket",

  /**本地环境三 */
  // ip: "http://192.168.1.56:8080/",
  // ip: "http://192.168.1.131:8015/sheer-api/",
  // // ipImg: "http://192.168.1.40:8081/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源

  ip: "https://pbcws.magic-beans.cn/sheer-api/",
  // serverImg: "http://192.168.1.56:8088/",
  ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  websocketIp: "wss://pbcws.magic-beans.cn/sheer-api/websocket",

  // /**本地环境四 */
  // ip: "http://192.168.1.111:8095/",
  // // serverImg: "http://192.168.1.111:8088/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // websocketIp: "ws://192.168.1.111:8095/websocket",   

  /**本地环境四 */
  // ip: "http://192.168.1.56:8080/",
  // // serverImg: "http://192.168.1.56:8088/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // websocketIp: "ws://192.168.1.56:8080/websocket",

  /**本地环境五 */
  // ip: "http://192.168.1.234:8080/",
  // serverImg: "http://192.234.1.234:8080/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // websocketIp: "ws://192.168.1.234:8080/websocket",

  /**本地环境 */
  // ip: "http://192.168.1.152:8282/",
  // // ipImg: "http://192.168.1.40/",
  //  ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // // serverImg: "http://192.168.1.111/sheer-api/",
  // websocketIp: "ws://192.168.1.152:8282/websocket",

  // ip: "http://192.168.1.66:8107/sheer-api/",
  //ipImg: "http://192.168.1.66:8107/sheer-api/images/",
  //websocketIp: "ws://192.168.1.66:8107/sheer-api/websocket",

  // ip: "http://139.129.111.76:8108/sheer-api/",
  // ipImg: "http://139.129.111.76:8108/sheer-api/images/",
  // websocketIp: "ws://139.129.111.76:8108/sheer-api/websocket",

  // ip: "http://pbcc.magic-beans.cn/sheer-api/",
  // ipImg: "http://pbcc.magic-beans.cn/sheer-api/images/",
  // websocketIp: "ws://pbcc.magic-beans.cn/sheer-api/websocket",

  /**新增服务器 114 */
  // ip: "https://tiger.magic-beans.cn/sheer-api/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",
  // serverImg: "https://tiger.magic-beans.cn/image",
  // websocketIp: "wss://tiger.magic-beans.cn/sheer-api/websocket",

  /* PBC线上环境 */
  // ip: "https://pbc.magic-beans.cn/sheer-api/",
  // // ipImg: "https://pbc.magic-beans.cn/sheer-api/images/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/", //替换阿里云图片资源
  // serverImg: "https://pbc.magic-beans.cn/image/",
  // websocketIp: "wss://pbc.magic-beans.cn/sheer-api/websocket", //暂时取消  S  websocketIp:     "wss://pbc.magic-beans.cn/sheer-api/websockets",

  /**新增测试服务器  外网 */
  // ip: "https://tiger.magic-beans.cn/sheer-api/",
  // // ipImg: "https://tiger.magic-beans.cn/sheer-api/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // serverImg: "https://tiger.magic-beans.cn/image",
  // websocketIp: "wss://tiger.magic-beans.cn/sheer-api/websocket",

  /**新增测试服务器  负载均衡 */
  // ip: "http://121.40.10.143:8080/sheer-api/",
  // // ipImg: "http://tiger.magic-beans.cn/sheer-api/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // serverImg: "http://121.40.10.143:8080/image",
  // websocketIp: "ws://121.40.10.143:8080/sheer-api/websockets",

  // 新增并发服务器   7-27
  // ip: "http://192.168.1.111:8022/sheer-api/",
  // ipImg: "http://192.168.1.111:8022/sheer-api/",
  // ipImg: "https://pbc-magic.oss-cn-hangzhou.aliyuncs.com/static/",//替换阿里云图片资源
  // serverImg: "http://192.168.1.111:8088/",
  // websocketIp: "ws://192.168.1.111:8022/sheer-api/websockets",

  // appId: "wx632a05e9589fad92",
  // secret: "60853048acf5bd0d769ee82f55284daf",
  appId: "wx56ea6c66d125c8ad",
  secret: "cda649a57cc208b5473436db6b693624",

  token: null,
  pbc: null,

  api: {
    login: "user/login", //登录
    bindOpenId: "user/bindOpenId", //绑定用户
    getCurrentLevel: "level/getCurrentLevel", //关卡
    getNotice: "notice/getNotice", //获取公告
    setData: "user/setData", //设置公共|音效
    checkSign: "user/checkSign", //检查是否签到
    countData: "user/countData", //排行榜已经个人统计
    sign: "user/sign", //签到
    getStudy: "study/getStudy", //获取每日一学的题目
    studyFinish: "study/studyFinish", //学习完毕
    buyProp: "prop/buyProp", //购买道具
    getSelfProp: "prop/getSelfProp", //获取用户所拥有的道具
    getProp: "prop/getProp", //获取道具列表
    addScore: "userScore/addScore", //分享获得的学分
    getSignDays: "user/getSignDays", //获取今天之前连续签到的天数
    getRadar: "user/getRadar", //获取雷达图数据
    useProp: "prop/useProp", //背包使用道具
    getScore: "user/getScore", //获取积分
    getInfo: "user/getInfo", //获取用户信息
    goHouse: "continueGame/isCreateGameHome", //获取好友是否已经创建好房间
    getText: "systemText/getText", //获取说明
    isStudyToday: "study/isStudyToday", //是否学习过
    getSelfRank: "user/getSelfRank", //全国排名、好友排名
    getOpenId: "wxClient/getOpenId", //获取openId
    getOnlineSize: "user/getOnlineSize", //获取在线人数
    isFinishAnswer: "user/isFinishAnswer", //是否通关
    isPlay: "config/isPlay", //是否可玩
    individual: '/config/individual/enabled',//查看个人排位赛是否可以进入
    getRadarV2: "user/getRadarV2", //单独雷达图
    getRadarOther: "user/getRadarOther", //个人中心其他数据
    getnewlist: "/news/list", //获取新闻列表
    getNewDetail: "/news/get/", //获取新闻列表
    getOrganization: "/organization/info", //通过邀请码查询机构
    getMechanism: "/user/modifyRealName", //修改用户姓名
    getMeachName: "/user/queryInfo", //获取用户机构信息
    mySchedule: '/team/mySchedule', // 查询我的赛程
    historySchedule: '/team/historySchedule',// 查询历史赛程
    getCurrentGameInfo: '/match/getCurrentGameInfo',//获取赛程团队信息
    teamWarScore: '/teamWar/team/score',//团队战绩信息
    scheduleHistory: '/teamWar/schedule/history/score',//历史经常接口
    teamWarTime: '/teamWar/time',//团战比赛时长
    getLastTime: '/match/getLastTime',//赛程倒计时
    matchStart: '/match/start',//团队匹配
    teamKeepAlive: '/keepAlive/validate',//战队心跳
    matchCacel: '/match/cacel',//取消匹配
    teamTimeOut: '/teamWar/answer/timeout',//答题超时
    teamAnswer: '/teamWar/answer',//答题
    isSubjectNext: '/teamWar/subject/next',//是否能进入下一题
    teamUserScore: '/teamWar/user/score',//团战本轮结果
    teamWarRank: '/teamWar/rank',//团战排行
    teamWarRankTeam: '/teamWar/rank/team',//团战排行
    editNickName: '/user/modifyNickName',//修改nickname
  },
  http: function (url, data, callback, errorCallback, isCallback) {
    let thas = this;
    wx.request({
      url: this.ip + url,
      data: data,
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded",
        token: thas.token
      },

      success: function (res) {
        console.log("******请求接口*****");
        console.log(data);
        console.log(thas.ip + url);
        console.log(res.data);
        console.log("******请求接口*****");

        if (isCallback) {
          if (res.data.code == 200) {
            callback(res);
          }
          else if (res.data.code == 2060) {
            wx.showModal({
              title: '当前人数过多，请稍后重试...',
              showCancel: false,
              confirmText: '返回',
              success: function (res) {
                wx.navigateBack({ changed: true });//返回上一页
              }
            });
          }
          else {
            wx.showToast({
              title: res.data.msg,
              icon: "none",
              duration: 2000
            });
          }
        } else {
          callback(res);
        }
      },
      fail: function (res) {
        thas.globalData.isBind = true;
        errorCallback(res);
      },
      complete: function (res) {
        errorCallback(res);
      }
    });
  },

  /**登录 */
  login: function () {
    let thas = this;
    wx.showLoading({
      title: "加载中",
      mask: true
    });
    return new Promise((resolve, reject) => {
      // 登录
      wx.login({
        success: res => {
          let thas = this;
          //获取openId
          thas.http(
            thas.api.getOpenId,
            {
              code: res.code
            },
            res => {
              if (!res.data.body) {
                wx.showToast({
                  title: "授权失败，请稍后再试",
                  icon: "none",
                  duration: 1000
                });
                return false;
              }
              wx.setStorage({
                key: "openId",
                data: res.data.body
              });
              thas.http(
                thas.api.login,
                {
                  openId: res.data.body
                },
                res => {
                  console.log("******登录用户******");
                  console.log(res, res.header["Set-Cookie"], res.data);
                  console.log("******登录用户******");
                  if (res.data.code == 200) {
                    wx.setStorage({
                      key: "serverUser",
                      data: res.data.body
                    });
                    thas.token = res.data.body.token;
                    // thas.pbc=thas.generatePbcId();
                    thas.globalData.isBind = false;
                    resolve(res.data.body);
                  } else if (res.data.code == 1002 || res.data.code == 2043) {
                    thas.globalData.isBind = true;
                    reject(false);
                  }
                },
                () => {
                  wx.hideLoading();
                },
                false
              );
            },
            () => {
              wx.hideLoading();
            },
            false
          );
        }
      });
    });
  },
  /**生成webscoket  附带唯一参数  reopen:是否为下一个连接创建唯一  cookie pbc */
  generatePbcId: function (reopen) {
    if (!reopen) {
      let temporary = wx.getStorageSync("generatePbcId");
      if (temporary) {
        return temporary;
      }
    }
    var s = [];
    var hexDigits = "0123456789abcdef";
    for (var i = 0; i < 36; i++) {
      s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
    s[8] = s[13] = s[18] = s[23] = "-";

    var uuid = s.join("");
    /**存储到本地   每次对话获取 */
    try {
      wx.setStorageSync("generatePbcId", uuid);
    } catch (e) { }
    return uuid;
  },
  /**附带请求参数  session */
  /**获取机器人提交答案的随机数 */
  robotRandom: function () {
    return Math.floor(Math.random() * 7);
  }
});

/**转format yyyy-MM-dd HH:mm:ss **/
Date.prototype.format = function (fmt) {
  var o = {
    "M+": this.getMonth() + 1, //月份
    "d+": this.getDate(), //日
    "h+": this.getHours(), //小时
    "m+": this.getMinutes(), //分
    "s+": this.getSeconds(), //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    S: this.getMilliseconds() //毫秒
  };
  if (/(y+)/.test(fmt))
    fmt = fmt.replace(
      RegExp.$1,
      (this.getFullYear() + "").substr(4 - RegExp.$1.length)
    );
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt))
      fmt = fmt.replace(
        RegExp.$1,
        RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length)
      );
  return fmt;
};
